// Contact form section (interactive) + site footer.
function ContactForm() {
  const { Input, Select, Textarea, Button, Eyebrow } = window.MarinerDesignSystem_43493c;
  const [sent, setSent] = React.useState(false);
  return (
    <section id="contact" style={{ background: "var(--cream)" }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "5rem 1.5rem", display: "grid", gridTemplateColumns: "0.9fr 1.1fr", gap: "3.5rem", alignItems: "start" }}>
        <div>
          <Eyebrow>Contact Us</Eyebrow>
          <h2 style={{ fontSize: "var(--text-h1)", margin: "0.75rem 0 1rem" }}>What's your next wealth question?</h2>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "var(--text-body-lg)", lineHeight: 1.6, color: "var(--text-body)", maxWidth: "40ch" }}>
            Whether you're planning ahead or navigating something new, we're here to help. Fill out the form and we'll be in touch.
          </p>
        </div>
        <div style={{ background: "var(--surface-raised)", borderRadius: "var(--radius-md)", padding: "2rem", boxShadow: "var(--shadow-md)" }}>
          {sent ? (
            <div style={{ padding: "2rem 0", textAlign: "center" }}>
              <div style={{ width: "44px", height: "2px", background: "var(--rust)", margin: "0 auto 1.25rem" }}></div>
              <h3 style={{ fontSize: "var(--text-h3)", marginBottom: "0.5rem" }}>Thank you.</h3>
              <p style={{ fontFamily: "var(--font-body)", color: "var(--text-muted)" }}>A Mariner advisor will reach out shortly.</p>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1.25rem" }}>
              <Input label="First Name" required placeholder="Jane" />
              <Input label="Last Name" required placeholder="Doe" />
              <Input label="Email" required type="email" placeholder="jane@email.com" />
              <Input label="Phone" type="tel" placeholder="(800) 384-1756" />
              <div style={{ gridColumn: "1 / -1" }}>
                <Select label="Are You A:" required placeholder="Select one" options={["Client", "Prospective Client", "Advisor/Investment Representative", "Other"]} />
              </div>
              <div style={{ gridColumn: "1 / -1" }}>
                <Textarea label="Message" required rows={4} placeholder="Tell us about your wealth question…" />
              </div>
              <div style={{ gridColumn: "1 / -1" }}>
                <Button variant="primary" size="lg" fullWidth type="submit">Submit</Button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}

function SiteFooter() {
  const cols = [
    { h: "Our Services", links: ["Wealth Planning", "Investment Management", "Tax Planning", "Estate Planning", "Trust Services"] },
    { h: "Who We Are", links: ["Philosophy", "Accolades", "Impact Report", "The Mariner Story"] },
    { h: "Connect", links: ["Our Team", "Locations", "Insights", "Careers", "Contact"] },
  ];
  return (
    <footer style={{ background: "var(--black)", color: "var(--cream)" }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "4rem 1.5rem 2rem", display: "grid", gridTemplateColumns: "1.4fr 1fr 1fr 1fr", gap: "2.5rem" }}>
        <div>
          <img src="../../assets/Mariner_Logo_Cream.png" alt="Mariner" style={{ height: "16px", width: "auto", display: "block" }} />
          <p style={{ fontFamily: "var(--font-body)", fontSize: "0.875rem", lineHeight: 1.6, color: "var(--text-on-dark-muted)", maxWidth: "34ch", marginTop: "1rem" }}>
            Wealth advice designed to last—creating a financial strategy designed to change with you.
          </p>
        </div>
        {cols.map((c) => (
          <div key={c.h}>
            <h4 style={{ fontFamily: "var(--font-ui)", fontSize: "0.75rem", fontWeight: 700, letterSpacing: "0.14em", textTransform: "uppercase", color: "var(--fast)", marginBottom: "1rem" }}>{c.h}</h4>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: "0.625rem" }}>
              {c.links.map((l) => (
                <li key={l}><a href="#" style={{ fontFamily: "var(--font-body)", fontSize: "0.9375rem", color: "var(--cream)" }}>{l}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div style={{ borderTop: "1px solid var(--border-on-dark)" }}>
        <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "1.25rem 1.5rem", display: "flex", justifyContent: "space-between", fontFamily: "var(--font-ui)", fontSize: "0.75rem", color: "var(--text-on-dark-muted)" }}>
          <span>© 2026 Mariner</span>
          <span style={{ display: "flex", gap: "1.25rem" }}>
            <a href="#" style={{ color: "var(--text-on-dark-muted)" }}>Privacy</a>
            <a href="#" style={{ color: "var(--text-on-dark-muted)" }}>Terms of Service</a>
            <a href="#" style={{ color: "var(--text-on-dark-muted)" }}>Form CRS</a>
          </span>
        </div>
      </div>
    </footer>
  );
}
window.ContactForm = ContactForm;
window.SiteFooter = SiteFooter;
