// Mid-page sections: accolade band, services split, client-type accordion, insights row.
function AccoladeBand() {
  const { Stat, TextLink, Divider } = window.MarinerDesignSystem_43493c;
  return (
    <section style={{ background: "var(--cream)" }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "4rem 1.5rem", display: "grid", gridTemplateColumns: "0.8fr 1.2fr", gap: "3rem", alignItems: "center" }}>
        <div style={{ display: "flex", gap: "3rem" }}>
          <Stat value="#6" label="Mega RIA — Barron's, 2025" />
          <Stat value="Top 5" label="Barron's Top 100 RIA, 2016–2024" />
        </div>
        <div>
          <h2 style={{ fontSize: "var(--text-h2)", marginBottom: "0.75rem" }}>Interested in working with a top-ranked advisor?</h2>
          <p style={{ fontFamily: "var(--font-body)", color: "var(--text-body)", lineHeight: 1.6, maxWidth: "56ch", margin: "0 0 1.25rem" }}>
            As a nationally recognized firm with a local presence across the country, we offer wealth management from advisors focused on your financial future.
          </p>
          <TextLink href="#">See All Accolades</TextLink>
        </div>
      </div>
    </section>
  );
}

function ServicesSplit() {
  const { Eyebrow, TextLink, Divider, Card } = window.MarinerDesignSystem_43493c;
  const blocks = [
    { eb: "For Individuals", title: "Services for individuals", body: "Your wealth is personal—and your strategy should be too. We bring together investments, taxes, estate planning, trusts and insurance into one integrated approach.", cta: "Explore Our Services" },
    { eb: "For Businesses", title: "Services for businesses", body: "From retirement plans and tax strategies to institutional cash management, we build financial strategies that work as hard as you do.", cta: "Discover Our Services" },
  ];
  return (
    <section style={{ background: "var(--surface-page)" }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "5rem 1.5rem", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "2rem" }}>
        {blocks.map((b) => (
          <div key={b.title} style={{ borderTop: "3px solid var(--rust)", paddingTop: "1.75rem" }}>
            <Eyebrow>{b.eb}</Eyebrow>
            <h2 style={{ fontSize: "var(--text-h2)", margin: "0.75rem 0 1rem" }}>{b.title}</h2>
            <p style={{ fontFamily: "var(--font-body)", color: "var(--text-body)", lineHeight: 1.65, maxWidth: "48ch", margin: "0 0 1.5rem" }}>{b.body}</p>
            <TextLink href="#">{b.cta}</TextLink>
          </div>
        ))}
      </div>
    </section>
  );
}

function ClientTypes() {
  const { Eyebrow, Accordion, Divider } = window.MarinerDesignSystem_43493c;
  const items = [
    { title: "Executives", content: "Negotiating benefits packages, establishing tax-efficient estate and trust plans, charitable-giving tax strategies, multi-state filing, and a plan built around your compensation." },
    { title: "Professional Athletes", content: "Personal insurance solutions to protect you on and off the field, multi-state tax filing, and income protection strategies for a career with an unusual arc." },
    { title: "Business Owners", content: "Valuation of your company, maintaining cash flow, and a succession strategy—a foundation for success today and in the future." },
    { title: "Medical Professionals", content: "Wealth management, charitable giving, asset protection and estate planning to provide financial security for you and your family." },
  ];
  return (
    <section style={{ background: "var(--black)", color: "var(--cream)" }}>
      <div style={{ maxWidth: "var(--container-narrow)", margin: "0 auto", padding: "5rem 1.5rem" }}>
        <div style={{ textAlign: "center", marginBottom: "2.5rem" }}>
          <Eyebrow tone="onDark">Specialized Advice</Eyebrow>
          <h2 style={{ fontSize: "var(--text-h1)", color: "var(--cream-tint)", margin: "0.75rem 0 0" }}>Your needs evolve. So do we.</h2>
        </div>
        <div style={{ "--border-subtle": "var(--border-on-dark)", "--text-strong": "var(--cream-tint)", "--text-body": "var(--access-tint)" }}>
          <Accordion items={items} defaultOpen={0} />
        </div>
      </div>
    </section>
  );
}

function InsightsRow() {
  const { Eyebrow, Card, TextLink, Badge } = window.MarinerDesignSystem_43493c;
  const posts = [
    { t: "Ramifications of Iran war", d: "July 1, 2026", r: "9 min", x: "The quest to keep nuclear weapons out of the hands of Iranian leaders has…" },
    { t: "A new Fed, familiar market dynamics", d: "July 1, 2026", r: "8 min", x: "The S&P 500 finished June down 2.9%, but still closed the second quarter with…" },
    { t: "Are you ready for your dream vacation?", d: "July 9, 2026", r: "Podcast", x: "Episode 170 of Your Life, Simplified—turning complex finances into simple steps." },
  ];
  return (
    <section style={{ background: "var(--surface-page)" }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "5rem 1.5rem" }}>
        <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: "2rem" }}>
          <div>
            <Eyebrow>Insights</Eyebrow>
            <h2 style={{ fontSize: "var(--text-h2)", margin: "0.5rem 0 0" }}>The latest from Mariner</h2>
          </div>
          <TextLink href="#">See All Insights</TextLink>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: "1.5rem" }}>
          {posts.map((p) => (
            <Card key={p.t} style={{ display: "flex", flexDirection: "column", gap: "0.75rem" }}>
              <div style={{ display: "flex", gap: "0.5rem", alignItems: "center", color: "var(--text-muted)", fontFamily: "var(--font-ui)", fontSize: "0.8125rem" }}>
                <span>{p.d}</span><span>·</span><span>{p.r}</span>
              </div>
              <h3 style={{ fontSize: "var(--text-h4)", lineHeight: 1.25 }}>{p.t}</h3>
              <p style={{ fontFamily: "var(--font-body)", fontSize: "0.9375rem", color: "var(--text-body)", lineHeight: 1.6, margin: 0, flex: 1 }}>{p.x}</p>
              <TextLink href="#">Read</TextLink>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
window.AccoladeBand = AccoladeBand;
window.ServicesSplit = ServicesSplit;
window.ClientTypes = ClientTypes;
window.InsightsRow = InsightsRow;
