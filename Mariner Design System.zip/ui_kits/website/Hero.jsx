// Hero + intro sections for the Mariner homepage.
function Hero() {
  const { Button, Eyebrow, Divider } = window.MarinerDesignSystem_43493c;
  return (
    <section style={{ background: "var(--black)", color: "var(--cream)", overflow: "hidden" }}>
      <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "5.5rem 1.5rem 6rem", display: "grid", gridTemplateColumns: "1.05fr 0.95fr", gap: "3rem", alignItems: "center" }}>
        <div>
          <Eyebrow tone="onDark">You're Ready for Mariner</Eyebrow>
          <h1 style={{ fontFamily: "var(--font-serif)", fontSize: "var(--text-display-l)", fontWeight: 400, lineHeight: 1.05, letterSpacing: "-0.01em", color: "var(--cream)", margin: "1rem 0 1.5rem" }}>
            Where your wealth goes <em>next</em> is up to you.
          </h1>
          <p style={{ fontFamily: "var(--font-body)", fontSize: "var(--text-lead)", lineHeight: 1.4, color: "var(--cream)", maxWidth: "46ch", margin: "0 0 2rem" }}>
            Behind every Mariner advisor is access to an in-house team of specialists in taxes, estate planning, insurance and more. Real power behind your plan.
          </p>
          <Button variant="accent" size="lg" as="a" href="#contact">Talk to an Advisor</Button>
        </div>
        <div style={{ position: "relative", height: "340px", borderRadius: "var(--radius-md)", overflow: "hidden", background: "linear-gradient(150deg, var(--access-deep), var(--black))", border: "1px solid var(--border-on-dark)", display: "flex", alignItems: "flex-end", padding: "2rem" }}>
          <div style={{ position: "absolute", inset: 0, background: "radial-gradient(120% 90% at 80% 0%, rgba(34,148,189,0.28), transparent 60%)" }}></div>
          <div style={{ position: "relative" }}>
            <div style={{ width: "44px", height: "2px", background: "var(--rust)", marginBottom: "0.9rem" }}></div>
            <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: "var(--text-h3)", lineHeight: 1.25, color: "var(--cream)", margin: 0 }}>
              Access to a wealth of knowledge and solutions.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
window.Hero = Hero;
