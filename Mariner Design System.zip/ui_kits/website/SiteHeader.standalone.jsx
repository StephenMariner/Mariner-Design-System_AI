// Mariner site header — utility bar + main nav. Consumes DS TextLink/Button.
function SiteHeader() {
  const { Button } = window.MarinerDesignSystem_43493c;
  const nav = ["Our Services", "Our Team", "Who We Are", "Insights", "Locations", "Contact"];
  const [open, setOpen] = React.useState(null);
  return (
    <header style={{ position: "sticky", top: 0, zIndex: 20 }}>
      {/* utility bar */}
      <div style={{ background: "var(--black)", color: "var(--cream)", fontFamily: "var(--font-ui)", fontSize: "0.75rem" }}>
        <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "0.5rem 1.5rem", display: "flex", justifyContent: "flex-end", gap: "1.5rem", letterSpacing: "0.04em" }}>
          <span style={{ marginRight: "auto", opacity: 0.8 }}>Call Us: 800-384-1756</span>
          {["Client Login", "Careers", "For Advisors/Firms"].map((l) => (
            <a key={l} href="#" style={{ color: "var(--cream)", opacity: 0.85 }}>{l}</a>
          ))}
        </div>
      </div>
      {/* main bar */}
      <div style={{ background: "var(--black)" }}>
        <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "1.1rem 1.5rem", display: "flex", alignItems: "center", gap: "2.5rem" }}>
          <a href="#" style={{ display: "flex", alignItems: "center" }}><img src={window.__resources.logoCream} alt="Mariner" style={{ height: "17px", width: "auto", display: "block" }} /></a>
          <nav style={{ display: "flex", gap: "1.75rem", marginLeft: "1rem" }}>
            {nav.map((n) => (
              <a key={n} href="#" onMouseEnter={() => setOpen(n)} onMouseLeave={() => setOpen(null)}
                style={{ fontFamily: "var(--font-ui)", fontSize: "0.9375rem", fontWeight: 500, color: open === n ? "var(--fast)" : "var(--cream)", transition: "color .15s" }}>
                {n}
              </a>
            ))}
          </nav>
          <div style={{ marginLeft: "auto" }}>
            <Button variant="accent" size="sm" as="a" href="#contact">Talk to an Advisor</Button>
          </div>
        </div>
      </div>
    </header>
  );
}
window.SiteHeader = SiteHeader;
