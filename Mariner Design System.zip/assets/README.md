# Assets

- `Mariner_Logo_Black.png` — official wordmark, black. Use on white/cream/light.
- `Mariner_Logo_Cream.png` — official wordmark, cream. Use on black.
- `Mariner_Logo_White.png` — official wordmark, white. Use on Access or when higher contrast is required.

Never redraw or approximate the wordmark; always place these files.

**Photography/illustration:** none supplied yet. Mariner collateral is photography-led
(warm, editorial). Add imagery here for use in kits and documents.

**Fonts:** Source Serif 4 (serving as Source Serif Pro) + Inter load from Google Fonts
CDN (see `tokens/fonts.css`). To self-host, add woff2 files to `assets/fonts/` and
swap the `@import` for local `@font-face` rules.
