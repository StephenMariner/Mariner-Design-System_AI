/* @ds-bundle: {"format":4,"namespace":"MarinerDesignSystem_43493c","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"TextLink","sourcePath":"components/actions/TextLink.jsx"},{"name":"Accordion","sourcePath":"components/content/Accordion.jsx"},{"name":"Badge","sourcePath":"components/content/Badge.jsx"},{"name":"Blockquote","sourcePath":"components/content/Blockquote.jsx"},{"name":"Card","sourcePath":"components/content/Card.jsx"},{"name":"Divider","sourcePath":"components/content/Divider.jsx"},{"name":"Eyebrow","sourcePath":"components/content/Eyebrow.jsx"},{"name":"Stat","sourcePath":"components/content/Stat.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"939bc7cdeb25","components/actions/TextLink.jsx":"8a19f67936be","components/content/Accordion.jsx":"644d492857c3","components/content/Badge.jsx":"b42d6ff2623d","components/content/Blockquote.jsx":"b1a6189078d4","components/content/Card.jsx":"d15c92a5fa43","components/content/Divider.jsx":"eceadfadb60e","components/content/Eyebrow.jsx":"987becc88ef4","components/content/Stat.jsx":"0ba38ebfde39","components/forms/Checkbox.jsx":"c7b44663261d","components/forms/Input.jsx":"4989bc836650","components/forms/Radio.jsx":"bdc56884d9e7","components/forms/Select.jsx":"a3b75492680d","components/forms/Textarea.jsx":"ae89c778932b","ui_kits/website/ContactFooter.jsx":"2bb313b7857b","ui_kits/website/ContactFooter.standalone.jsx":"d944f5d93dc4","ui_kits/website/Hero.jsx":"6d65a46eb330","ui_kits/website/HomeSections.jsx":"b986d8576c2b","ui_kits/website/SiteHeader.jsx":"1caab62ed1a5","ui_kits/website/SiteHeader.standalone.jsx":"f0df0bb389a8"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MarinerDesignSystem_43493c = window.MarinerDesignSystem_43493c || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Mariner Button — primary call-to-action.
 * Brand CTAs are uppercase, letter-spaced, squared corners.
 * Resting fills are white, black, or cream only — rust is never a resting state.
 * All variants hover to Access blue with white text.
 */
function Button({
  children,
  variant = "primary",
  // primary | accent | secondary | ghost
  size = "md",
  // sm | md | lg
  as = "button",
  disabled = false,
  fullWidth = false,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "0.5rem 1rem",
      fontSize: "0.6875rem"
    },
    md: {
      padding: "0.8125rem 1.5rem",
      fontSize: "0.75rem"
    },
    lg: {
      padding: "1rem 2rem",
      fontSize: "0.8125rem"
    }
  };
  const variants = {
    primary: {
      background: "var(--action-primary)",
      color: "var(--action-primary-text)",
      border: "1px solid var(--action-primary)"
    },
    accent: {
      background: "var(--action-accent)",
      color: "var(--action-accent-text)",
      border: "1px solid var(--action-accent-border)"
    },
    secondary: {
      background: "transparent",
      color: "var(--action-primary)",
      border: "1px solid var(--border-strong)"
    },
    ghost: {
      background: "transparent",
      color: "var(--action-primary)",
      border: "1px solid transparent"
    }
  };
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    disabled: as === "button" ? disabled : undefined,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "0.5rem",
      width: fullWidth ? "100%" : "auto",
      fontFamily: "var(--font-ui)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      lineHeight: 1,
      borderRadius: "var(--radius-sm)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "background 0.18s ease, color 0.18s ease, border-color 0.18s ease",
      textDecoration: "none",
      ...sizes[size],
      ...variants[variant],
      ...style
    },
    onMouseEnter: e => {
      if (disabled) return;
      e.currentTarget.style.background = "var(--action-hover-bg)";
      e.currentTarget.style.color = "var(--action-hover-text)";
      e.currentTarget.style.borderColor = "var(--action-hover-bg)";
    },
    onMouseLeave: e => {
      if (disabled) return;
      e.currentTarget.style.background = variants[variant].background;
      e.currentTarget.style.color = variants[variant].color;
      e.currentTarget.style.borderColor = variant === "secondary" ? "var(--border-strong)" : variant === "ghost" ? "transparent" : variant === "accent" ? "var(--action-accent-border)" : variants[variant].background;
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/TextLink.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TextLink — inline editorial CTA with a trailing chevron, as seen in
 * "Read >" / "Learn More" links across the site.
 */
function TextLink({
  children,
  href = "#",
  arrow = true,
  tone = "default",
  style = {},
  ...rest
}) {
  const tones = {
    default: "var(--text-link)",
    accent: "var(--text-accent)",
    onDark: "var(--cream)"
  };
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "0.4rem",
      fontFamily: "var(--font-ui)",
      fontWeight: "var(--weight-semibold)",
      fontSize: "var(--text-body-sm)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      color: tones[tone],
      textDecoration: "none",
      borderBottom: "1px solid currentColor",
      paddingBottom: "2px",
      transition: "opacity 0.18s ease",
      ...style
    },
    onMouseEnter: e => e.currentTarget.style.opacity = "0.65",
    onMouseLeave: e => e.currentTarget.style.opacity = "1"
  }, rest), children, arrow && /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      fontWeight: 400
    }
  }, "\u203A"));
}
Object.assign(__ds_scope, { TextLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/TextLink.jsx", error: String((e && e.message) || e) }); }

// components/content/Accordion.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Accordion — expandable list, as used in the "Your needs evolve" section
 * (Executives / Athletes / Business Owners …). Serif headers, brass +/- marker.
 */
function Accordion({
  items = [],
  defaultOpen = 0,
  style = {},
  ...rest
}) {
  const [open, setOpen] = React.useState(defaultOpen);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      borderTop: "1px solid var(--border-subtle)",
      ...style
    }
  }, rest), items.map((item, i) => {
    const isOpen = open === i;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => setOpen(isOpen ? -1 : i),
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        width: "100%",
        gap: "1rem",
        padding: "1.25rem 0",
        background: "transparent",
        border: "none",
        cursor: "pointer",
        textAlign: "left"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-serif)",
        fontSize: "var(--text-h4)",
        fontWeight: "var(--weight-title)",
        color: "var(--text-strong)"
      }
    }, item.title), /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        fontFamily: "var(--font-ui)",
        fontSize: "1.25rem",
        lineHeight: 1,
        color: "var(--rust)",
        flexShrink: 0,
        transition: "transform 0.2s ease",
        transform: isOpen ? "rotate(45deg)" : "none"
      }
    }, "+")), isOpen && /*#__PURE__*/React.createElement("div", {
      style: {
        paddingBottom: "1.5rem",
        maxWidth: "62ch",
        fontFamily: "var(--font-body)",
        fontSize: "var(--text-body)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--text-body)"
      }
    }, item.content));
  }));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/content/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Badge — stroke-outline label. Stroke and text always match. */
function Badge({
  children,
  tone = "neutral",
  onDark = false,
  style = {},
  ...rest
}) {
  const tones = {
    neutral: onDark ? "var(--white)" : "var(--black)",
    accent: onDark ? "var(--white)" : "var(--black)",
    navy: onDark ? "var(--white)" : "var(--black)",
    success: "var(--success)",
    warning: "var(--warning)",
    danger: "var(--danger)"
  };
  const ink = tones[tone] || tones.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-caption)",
      fontWeight: "var(--weight-semibold)",
      lineHeight: 1,
      padding: "0.3rem 0.6rem",
      borderRadius: "var(--radius-pill)",
      background: "transparent",
      color: ink,
      border: `1px solid ${ink}`,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Badge.jsx", error: String((e && e.message) || e) }); }

// components/content/Blockquote.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Blockquote — editorial pull quote with serif type and brass rule. */
function Blockquote({
  children,
  cite,
  tone = "default",
  style = {},
  ...rest
}) {
  const onDark = tone === "onDark";
  return /*#__PURE__*/React.createElement("figure", _extends({
    style: {
      margin: 0,
      paddingLeft: "1.5rem",
      borderLeft: "3px solid var(--rule-accent)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      fontFamily: "var(--font-serif)",
      fontSize: "var(--text-h3)",
      fontWeight: "var(--weight-regular)",
      fontStyle: "italic",
      lineHeight: "var(--leading-snug)",
      color: onDark ? "var(--text-on-dark)" : "var(--text-strong)"
    }
  }, children), cite && /*#__PURE__*/React.createElement("figcaption", {
    style: {
      marginTop: "1rem",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-caption)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: onDark ? "var(--text-on-dark-muted)" : "var(--text-muted)"
    }
  }, cite));
}
Object.assign(__ds_scope, { Blockquote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Blockquote.jsx", error: String((e && e.message) || e) }); }

// components/content/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — content container. Two surfaces: light (default, on cream) and
 * a subtle raised variant with border. Used for insights teasers, service
 * blocks, form panels.
 */
function Card({
  children,
  variant = "default",
  padding = "1.75rem",
  style = {},
  ...rest
}) {
  const variants = {
    default: {
      background: "var(--surface-raised)",
      border: "1px solid var(--border-subtle)",
      boxShadow: "var(--shadow-sm)"
    },
    flat: {
      background: "var(--surface-sunken)",
      border: "1px solid transparent",
      boxShadow: "none"
    },
    outline: {
      background: "transparent",
      border: "1px solid var(--border-default)",
      boxShadow: "none"
    },
    inverse: {
      background: "var(--surface-inverse)",
      border: "1px solid var(--border-on-dark)",
      boxShadow: "none"
    }
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      borderRadius: "var(--radius-md)",
      padding,
      color: variant === "inverse" ? "var(--text-on-dark)" : "var(--text-body)",
      ...variants[variant],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Card.jsx", error: String((e && e.message) || e) }); }

// components/content/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Divider — hairline rule. Optional short brass "accent" style. */
function Divider({
  variant = "default",
  tone = "default",
  style = {},
  ...rest
}) {
  const onDark = tone === "onDark";
  if (variant === "accent") {
    return /*#__PURE__*/React.createElement("hr", _extends({
      style: {
        border: 0,
        height: "2px",
        width: "48px",
        background: "var(--rule-accent)",
        margin: 0,
        ...style
      }
    }, rest));
  }
  return /*#__PURE__*/React.createElement("hr", _extends({
    style: {
      border: 0,
      height: "1px",
      background: onDark ? "var(--border-on-dark)" : "var(--border-subtle)",
      margin: 0,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Divider.jsx", error: String((e && e.message) || e) }); }

// components/content/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Eyebrow — uppercase overline label above headings. Arial Regular; Access or Rust per brand. */
function Eyebrow({
  children,
  tone = "accent",
  style = {},
  ...rest
}) {
  const tones = {
    accent: "var(--text-accent)",
    access: "var(--text-heading-accent)",
    muted: "var(--text-muted)",
    onDark: "var(--fast)"
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-block",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-eyebrow)",
      fontWeight: "var(--weight-eyebrow)",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: tones[tone],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/content/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Stat — large serif figure with label, for accolades and metrics
 * (e.g. "#6 Mega RIA", "$100B+ AUM").
 */
function Stat({
  value,
  label,
  tone = "default",
  align = "left",
  style = {},
  ...rest
}) {
  const onDark = tone === "onDark";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      textAlign: align,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-serif)",
      fontSize: "var(--text-display-m)",
      fontWeight: "var(--weight-title)",
      lineHeight: 1,
      letterSpacing: "var(--tracking-tight)",
      color: onDark ? "var(--fast)" : "var(--text-heading-accent)"
    }
  }, value), label && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "0.5rem",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-body-sm)",
      color: onDark ? "var(--text-on-dark-muted)" : "var(--text-muted)",
      maxWidth: "22ch",
      ...(align === "center" ? {
        marginInline: "auto"
      } : {})
    }
  }, label));
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Stat.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Checkbox with label. Uses brass accent when checked. */
function Checkbox({
  label,
  checked,
  defaultChecked,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "0.625rem",
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body-sm)",
      color: "var(--text-body)",
      cursor: "pointer",
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    defaultChecked: defaultChecked,
    style: {
      width: "1.05rem",
      height: "1.05rem",
      accentColor: "var(--black)",
      cursor: "pointer"
    }
  }, rest)), label);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Mariner text input with optional label + required marker (matches site forms). */
function Input({
  label,
  required = false,
  id,
  error,
  style = {},
  ...rest
}) {
  const inputId = id || (label ? `in-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "0.375rem",
      width: "100%"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-caption)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--danger)"
    }
  }, " *")), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body)",
      color: "var(--text-body)",
      background: "var(--surface-raised)",
      border: `1px solid ${error ? "var(--danger)" : "var(--border-default)"}`,
      borderRadius: "var(--radius-md)",
      padding: "0.6875rem 0.875rem",
      width: "100%",
      outline: "none",
      transition: "border-color 0.18s ease, box-shadow 0.18s ease",
      ...style
    },
    onFocus: e => {
      e.currentTarget.style.borderColor = "var(--rust)";
      e.currentTarget.style.boxShadow = "var(--shadow-focus)";
    },
    onBlur: e => {
      e.currentTarget.style.borderColor = error ? "var(--danger)" : "var(--border-default)";
      e.currentTarget.style.boxShadow = "none";
    }
  }, rest)), error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-caption)",
      color: "var(--danger)"
    }
  }, error));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Radio option with label. Use several with the same `name`. */
function Radio({
  label,
  name,
  value,
  checked,
  defaultChecked,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "0.625rem",
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body-sm)",
      color: "var(--text-body)",
      cursor: "pointer",
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    defaultChecked: defaultChecked,
    style: {
      width: "1.05rem",
      height: "1.05rem",
      accentColor: "var(--black)",
      cursor: "pointer"
    }
  }, rest)), label);
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Select dropdown matching form styling ("Are You A:" pattern). */
function Select({
  label,
  required = false,
  id,
  options = [],
  placeholder,
  style = {},
  ...rest
}) {
  const inputId = id || (label ? `sel-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "0.375rem",
      width: "100%"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-caption)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--danger)"
    }
  }, " *")), /*#__PURE__*/React.createElement("select", _extends({
    id: inputId,
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body)",
      color: "var(--text-body)",
      background: "var(--surface-raised)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      padding: "0.6875rem 0.875rem",
      width: "100%",
      outline: "none",
      cursor: "pointer",
      appearance: "none",
      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath fill='%236B7780' d='M1 1l5 5 5-5'/%3E%3C/svg%3E\")",
      backgroundRepeat: "no-repeat",
      backgroundPosition: "right 0.875rem center",
      transition: "border-color 0.18s ease, box-shadow 0.18s ease",
      ...style
    },
    onFocus: e => {
      e.currentTarget.style.borderColor = "var(--rust)";
      e.currentTarget.style.boxShadow = "var(--shadow-focus)";
    },
    onBlur: e => {
      e.currentTarget.style.borderColor = "var(--border-default)";
      e.currentTarget.style.boxShadow = "none";
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), options.map(o => {
    const val = typeof o === "string" ? o : o.value;
    const lbl = typeof o === "string" ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: val,
      value: val
    }, lbl);
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Multi-line text input matching Input's styling. */
function Textarea({
  label,
  required = false,
  id,
  rows = 4,
  style = {},
  ...rest
}) {
  const inputId = id || (label ? `ta-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "0.375rem",
      width: "100%"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-caption)",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--danger)"
    }
  }, " *")), /*#__PURE__*/React.createElement("textarea", _extends({
    id: inputId,
    rows: rows,
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body)",
      color: "var(--text-body)",
      background: "var(--surface-raised)",
      border: "1px solid var(--border-default)",
      borderRadius: "var(--radius-md)",
      padding: "0.6875rem 0.875rem",
      width: "100%",
      outline: "none",
      resize: "vertical",
      transition: "border-color 0.18s ease, box-shadow 0.18s ease",
      ...style
    },
    onFocus: e => {
      e.currentTarget.style.borderColor = "var(--rust)";
      e.currentTarget.style.boxShadow = "var(--shadow-focus)";
    },
    onBlur: e => {
      e.currentTarget.style.borderColor = "var(--border-default)";
      e.currentTarget.style.boxShadow = "none";
    }
  }, rest)));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ContactFooter.jsx
try { (() => {
// Contact form section (interactive) + site footer.
function ContactForm() {
  const {
    Input,
    Select,
    Textarea,
    Button,
    Eyebrow
  } = window.MarinerDesignSystem_43493c;
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("section", {
    id: "contact",
    style: {
      background: "var(--cream)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "5rem 1.5rem",
      display: "grid",
      gridTemplateColumns: "0.9fr 1.1fr",
      gap: "3.5rem",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Contact Us"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h1)",
      margin: "0.75rem 0 1rem"
    }
  }, "What's your next wealth question?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body-lg)",
      lineHeight: 1.6,
      color: "var(--text-body)",
      maxWidth: "40ch"
    }
  }, "Whether you're planning ahead or navigating something new, we're here to help. Fill out the form and we'll be in touch.")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-raised)",
      borderRadius: "var(--radius-md)",
      padding: "2rem",
      boxShadow: "var(--shadow-md)"
    }
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "2rem 0",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "44px",
      height: "2px",
      background: "var(--rust)",
      margin: "0 auto 1.25rem"
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--text-h3)",
      marginBottom: "0.5rem"
    }
  }, "Thank you."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      color: "var(--text-muted)"
    }
  }, "A Mariner advisor will reach out shortly.")) : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "1.25rem"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "First Name",
    required: true,
    placeholder: "Jane"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Last Name",
    required: true,
    placeholder: "Doe"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    required: true,
    type: "email",
    placeholder: "jane@email.com"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Phone",
    type: "tel",
    placeholder: "(800) 384-1756"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1"
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Are You A:",
    required: true,
    placeholder: "Select one",
    options: ["Client", "Prospective Client", "Advisor/Investment Representative", "Other"]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1"
    }
  }, /*#__PURE__*/React.createElement(Textarea, {
    label: "Message",
    required: true,
    rows: 4,
    placeholder: "Tell us about your wealth question\u2026"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    type: "submit"
  }, "Submit"))))));
}
function SiteFooter() {
  const cols = [{
    h: "Our Services",
    links: ["Wealth Planning", "Investment Management", "Tax Planning", "Estate Planning", "Trust Services"]
  }, {
    h: "Who We Are",
    links: ["Philosophy", "Accolades", "Impact Report", "The Mariner Story"]
  }, {
    h: "Connect",
    links: ["Our Team", "Locations", "Insights", "Careers", "Contact"]
  }];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--black)",
      color: "var(--cream)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "4rem 1.5rem 2rem",
      display: "grid",
      gridTemplateColumns: "1.4fr 1fr 1fr 1fr",
      gap: "2.5rem"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/Mariner_Logo_Cream.png",
    alt: "Mariner",
    style: {
      height: "16px",
      width: "auto",
      display: "block"
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "0.875rem",
      lineHeight: 1.6,
      color: "var(--text-on-dark-muted)",
      maxWidth: "34ch",
      marginTop: "1rem"
    }
  }, "Wealth advice designed to last\u2014creating a financial strategy designed to change with you.")), cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.h
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "0.75rem",
      fontWeight: 700,
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--fast)",
      marginBottom: "1rem"
    }
  }, c.h), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: 0,
      display: "flex",
      flexDirection: "column",
      gap: "0.625rem"
    }
  }, c.links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "0.9375rem",
      color: "var(--cream)"
    }
  }, l))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--border-on-dark)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "1.25rem 1.5rem",
      display: "flex",
      justifyContent: "space-between",
      fontFamily: "var(--font-ui)",
      fontSize: "0.75rem",
      color: "var(--text-on-dark-muted)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Mariner"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: "1.25rem"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "var(--text-on-dark-muted)"
    }
  }, "Privacy"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "var(--text-on-dark-muted)"
    }
  }, "Terms of Service"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "var(--text-on-dark-muted)"
    }
  }, "Form CRS")))));
}
window.ContactForm = ContactForm;
window.SiteFooter = SiteFooter;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ContactFooter.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ContactFooter.standalone.jsx
try { (() => {
// Contact form section (interactive) + site footer.
function ContactForm() {
  const {
    Input,
    Select,
    Textarea,
    Button,
    Eyebrow
  } = window.MarinerDesignSystem_43493c;
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("section", {
    id: "contact",
    style: {
      background: "var(--cream)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "5rem 1.5rem",
      display: "grid",
      gridTemplateColumns: "0.9fr 1.1fr",
      gap: "3.5rem",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Contact Us"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h1)",
      margin: "0.75rem 0 1rem"
    }
  }, "What's your next wealth question?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body-lg)",
      lineHeight: 1.6,
      color: "var(--text-body)",
      maxWidth: "40ch"
    }
  }, "Whether you're planning ahead or navigating something new, we're here to help. Fill out the form and we'll be in touch.")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-raised)",
      borderRadius: "var(--radius-md)",
      padding: "2rem",
      boxShadow: "var(--shadow-md)"
    }
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "2rem 0",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "44px",
      height: "2px",
      background: "var(--rust)",
      margin: "0 auto 1.25rem"
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--text-h3)",
      marginBottom: "0.5rem"
    }
  }, "Thank you."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      color: "var(--text-muted)"
    }
  }, "A Mariner advisor will reach out shortly.")) : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "1.25rem"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "First Name",
    required: true,
    placeholder: "Jane"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Last Name",
    required: true,
    placeholder: "Doe"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Email",
    required: true,
    type: "email",
    placeholder: "jane@email.com"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Phone",
    type: "tel",
    placeholder: "(800) 384-1756"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1"
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Are You A:",
    required: true,
    placeholder: "Select one",
    options: ["Client", "Prospective Client", "Advisor/Investment Representative", "Other"]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1"
    }
  }, /*#__PURE__*/React.createElement(Textarea, {
    label: "Message",
    required: true,
    rows: 4,
    placeholder: "Tell us about your wealth question\u2026"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: "1 / -1"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    type: "submit"
  }, "Submit"))))));
}
function SiteFooter() {
  const cols = [{
    h: "Our Services",
    links: ["Wealth Planning", "Investment Management", "Tax Planning", "Estate Planning", "Trust Services"]
  }, {
    h: "Who We Are",
    links: ["Philosophy", "Accolades", "Impact Report", "The Mariner Story"]
  }, {
    h: "Connect",
    links: ["Our Team", "Locations", "Insights", "Careers", "Contact"]
  }];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--black)",
      color: "var(--cream)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "4rem 1.5rem 2rem",
      display: "grid",
      gridTemplateColumns: "1.4fr 1fr 1fr 1fr",
      gap: "2.5rem"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: window.__resources.logoCream,
    alt: "Mariner",
    style: {
      height: "16px",
      width: "auto",
      display: "block"
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "0.875rem",
      lineHeight: 1.6,
      color: "var(--text-on-dark-muted)",
      maxWidth: "34ch",
      marginTop: "1rem"
    }
  }, "Wealth advice designed to last\u2014creating a financial strategy designed to change with you.")), cols.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.h
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "0.75rem",
      fontWeight: 700,
      letterSpacing: "0.14em",
      textTransform: "uppercase",
      color: "var(--fast)",
      marginBottom: "1rem"
    }
  }, c.h), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: 0,
      display: "flex",
      flexDirection: "column",
      gap: "0.625rem"
    }
  }, c.links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "0.9375rem",
      color: "var(--cream)"
    }
  }, l))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--border-on-dark)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "1.25rem 1.5rem",
      display: "flex",
      justifyContent: "space-between",
      fontFamily: "var(--font-ui)",
      fontSize: "0.75rem",
      color: "var(--text-on-dark-muted)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Mariner"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: "1.25rem"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "var(--text-on-dark-muted)"
    }
  }, "Privacy"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "var(--text-on-dark-muted)"
    }
  }, "Terms of Service"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "var(--text-on-dark-muted)"
    }
  }, "Form CRS")))));
}
window.ContactForm = ContactForm;
window.SiteFooter = SiteFooter;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ContactFooter.standalone.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
// Hero + intro sections for the Mariner homepage.
function Hero() {
  const {
    Button,
    Eyebrow,
    Divider
  } = window.MarinerDesignSystem_43493c;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--black)",
      color: "var(--cream)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "5.5rem 1.5rem 6rem",
      display: "grid",
      gridTemplateColumns: "1.05fr 0.95fr",
      gap: "3rem",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "onDark"
  }, "You're Ready for Mariner"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-serif)",
      fontSize: "var(--text-display-l)",
      fontWeight: 400,
      lineHeight: 1.05,
      letterSpacing: "-0.01em",
      color: "var(--cream)",
      margin: "1rem 0 1.5rem"
    }
  }, "Where your wealth goes ", /*#__PURE__*/React.createElement("em", null, "next"), " is up to you."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-lead)",
      lineHeight: 1.4,
      color: "var(--cream)",
      maxWidth: "46ch",
      margin: "0 0 2rem"
    }
  }, "Behind every Mariner advisor is access to an in-house team of specialists in taxes, estate planning, insurance and more. Real power behind your plan."), /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "lg",
    as: "a",
    href: "#contact"
  }, "Talk to an Advisor")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: "340px",
      borderRadius: "var(--radius-md)",
      overflow: "hidden",
      background: "linear-gradient(150deg, var(--access-deep), var(--black))",
      border: "1px solid var(--border-on-dark)",
      display: "flex",
      alignItems: "flex-end",
      padding: "2rem"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "radial-gradient(120% 90% at 80% 0%, rgba(34,148,189,0.28), transparent 60%)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: "44px",
      height: "2px",
      background: "var(--rust)",
      marginBottom: "0.9rem"
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      fontSize: "var(--text-h3)",
      lineHeight: 1.25,
      color: "var(--cream)",
      margin: 0
    }
  }, "Access to a wealth of knowledge and solutions.")))));
}
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeSections.jsx
try { (() => {
// Mid-page sections: accolade band, services split, client-type accordion, insights row.
function AccoladeBand() {
  const {
    Stat,
    TextLink,
    Divider
  } = window.MarinerDesignSystem_43493c;
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--cream)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "4rem 1.5rem",
      display: "grid",
      gridTemplateColumns: "0.8fr 1.2fr",
      gap: "3rem",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "3rem"
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    value: "#6",
    label: "Mega RIA \u2014 Barron's, 2025"
  }), /*#__PURE__*/React.createElement(Stat, {
    value: "Top 5",
    label: "Barron's Top 100 RIA, 2016\u20132024"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h2)",
      marginBottom: "0.75rem"
    }
  }, "Interested in working with a top-ranked advisor?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      color: "var(--text-body)",
      lineHeight: 1.6,
      maxWidth: "56ch",
      margin: "0 0 1.25rem"
    }
  }, "As a nationally recognized firm with a local presence across the country, we offer wealth management from advisors focused on your financial future."), /*#__PURE__*/React.createElement(TextLink, {
    href: "#"
  }, "See All Accolades"))));
}
function ServicesSplit() {
  const {
    Eyebrow,
    TextLink,
    Divider,
    Card
  } = window.MarinerDesignSystem_43493c;
  const blocks = [{
    eb: "For Individuals",
    title: "Services for individuals",
    body: "Your wealth is personal—and your strategy should be too. We bring together investments, taxes, estate planning, trusts and insurance into one integrated approach.",
    cta: "Explore Our Services"
  }, {
    eb: "For Businesses",
    title: "Services for businesses",
    body: "From retirement plans and tax strategies to institutional cash management, we build financial strategies that work as hard as you do.",
    cta: "Discover Our Services"
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "5rem 1.5rem",
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "2rem"
    }
  }, blocks.map(b => /*#__PURE__*/React.createElement("div", {
    key: b.title,
    style: {
      borderTop: "3px solid var(--rust)",
      paddingTop: "1.75rem"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, b.eb), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h2)",
      margin: "0.75rem 0 1rem"
    }
  }, b.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      color: "var(--text-body)",
      lineHeight: 1.65,
      maxWidth: "48ch",
      margin: "0 0 1.5rem"
    }
  }, b.body), /*#__PURE__*/React.createElement(TextLink, {
    href: "#"
  }, b.cta)))));
}
function ClientTypes() {
  const {
    Eyebrow,
    Accordion,
    Divider
  } = window.MarinerDesignSystem_43493c;
  const items = [{
    title: "Executives",
    content: "Negotiating benefits packages, establishing tax-efficient estate and trust plans, charitable-giving tax strategies, multi-state filing, and a plan built around your compensation."
  }, {
    title: "Professional Athletes",
    content: "Personal insurance solutions to protect you on and off the field, multi-state tax filing, and income protection strategies for a career with an unusual arc."
  }, {
    title: "Business Owners",
    content: "Valuation of your company, maintaining cash flow, and a succession strategy—a foundation for success today and in the future."
  }, {
    title: "Medical Professionals",
    content: "Wealth management, charitable giving, asset protection and estate planning to provide financial security for you and your family."
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--black)",
      color: "var(--cream)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-narrow)",
      margin: "0 auto",
      padding: "5rem 1.5rem"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      marginBottom: "2.5rem"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "onDark"
  }, "Specialized Advice"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h1)",
      color: "var(--cream-tint)",
      margin: "0.75rem 0 0"
    }
  }, "Your needs evolve. So do we.")), /*#__PURE__*/React.createElement("div", {
    style: {
      "--border-subtle": "var(--border-on-dark)",
      "--text-strong": "var(--cream-tint)",
      "--text-body": "var(--access-tint)"
    }
  }, /*#__PURE__*/React.createElement(Accordion, {
    items: items,
    defaultOpen: 0
  }))));
}
function InsightsRow() {
  const {
    Eyebrow,
    Card,
    TextLink,
    Badge
  } = window.MarinerDesignSystem_43493c;
  const posts = [{
    t: "Ramifications of Iran war",
    d: "July 1, 2026",
    r: "9 min",
    x: "The quest to keep nuclear weapons out of the hands of Iranian leaders has…"
  }, {
    t: "A new Fed, familiar market dynamics",
    d: "July 1, 2026",
    r: "8 min",
    x: "The S&P 500 finished June down 2.9%, but still closed the second quarter with…"
  }, {
    t: "Are you ready for your dream vacation?",
    d: "July 9, 2026",
    r: "Podcast",
    x: "Episode 170 of Your Life, Simplified—turning complex finances into simple steps."
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "5rem 1.5rem"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-end",
      justifyContent: "space-between",
      marginBottom: "2rem"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Insights"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h2)",
      margin: "0.5rem 0 0"
    }
  }, "The latest from Mariner")), /*#__PURE__*/React.createElement(TextLink, {
    href: "#"
  }, "See All Insights")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,1fr)",
      gap: "1.5rem"
    }
  }, posts.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.t,
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "0.75rem"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "0.5rem",
      alignItems: "center",
      color: "var(--text-muted)",
      fontFamily: "var(--font-ui)",
      fontSize: "0.8125rem"
    }
  }, /*#__PURE__*/React.createElement("span", null, p.d), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, p.r)), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--text-h4)",
      lineHeight: 1.25
    }
  }, p.t), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "0.9375rem",
      color: "var(--text-body)",
      lineHeight: 1.6,
      margin: 0,
      flex: 1
    }
  }, p.x), /*#__PURE__*/React.createElement(TextLink, {
    href: "#"
  }, "Read"))))));
}
window.AccoladeBand = AccoladeBand;
window.ServicesSplit = ServicesSplit;
window.ClientTypes = ClientTypes;
window.InsightsRow = InsightsRow;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeSections.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SiteHeader.jsx
try { (() => {
// Mariner site header — utility bar + main nav. Consumes DS TextLink/Button.
function SiteHeader() {
  const {
    Button
  } = window.MarinerDesignSystem_43493c;
  const nav = ["Our Services", "Our Team", "Who We Are", "Insights", "Locations", "Contact"];
  const [open, setOpen] = React.useState(null);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--black)",
      color: "var(--cream)",
      fontFamily: "var(--font-ui)",
      fontSize: "0.75rem"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0.5rem 1.5rem",
      display: "flex",
      justifyContent: "flex-end",
      gap: "1.5rem",
      letterSpacing: "0.04em"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      marginRight: "auto",
      opacity: 0.8
    }
  }, "Call Us: 800-384-1756"), ["Client Login", "Careers", "For Advisors/Firms"].map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      color: "var(--cream)",
      opacity: 0.85
    }
  }, l)))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--black)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "1.1rem 1.5rem",
      display: "flex",
      alignItems: "center",
      gap: "2.5rem"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/Mariner_Logo_Cream.png",
    alt: "Mariner",
    style: {
      height: "17px",
      width: "auto",
      display: "block"
    }
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: "1.75rem",
      marginLeft: "1rem"
    }
  }, nav.map(n => /*#__PURE__*/React.createElement("a", {
    key: n,
    href: "#",
    onMouseEnter: () => setOpen(n),
    onMouseLeave: () => setOpen(null),
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "0.9375rem",
      fontWeight: 500,
      color: open === n ? "var(--fast)" : "var(--cream)",
      transition: "color .15s"
    }
  }, n))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "sm",
    as: "a",
    href: "#contact"
  }, "Talk to an Advisor")))));
}
window.SiteHeader = SiteHeader;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SiteHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SiteHeader.standalone.jsx
try { (() => {
// Mariner site header — utility bar + main nav. Consumes DS TextLink/Button.
function SiteHeader() {
  const {
    Button
  } = window.MarinerDesignSystem_43493c;
  const nav = ["Our Services", "Our Team", "Who We Are", "Insights", "Locations", "Contact"];
  const [open, setOpen] = React.useState(null);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--black)",
      color: "var(--cream)",
      fontFamily: "var(--font-ui)",
      fontSize: "0.75rem"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "0.5rem 1.5rem",
      display: "flex",
      justifyContent: "flex-end",
      gap: "1.5rem",
      letterSpacing: "0.04em"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      marginRight: "auto",
      opacity: 0.8
    }
  }, "Call Us: 800-384-1756"), ["Client Login", "Careers", "For Advisors/Firms"].map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      color: "var(--cream)",
      opacity: 0.85
    }
  }, l)))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--black)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-max)",
      margin: "0 auto",
      padding: "1.1rem 1.5rem",
      display: "flex",
      alignItems: "center",
      gap: "2.5rem"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: window.__resources.logoCream,
    alt: "Mariner",
    style: {
      height: "17px",
      width: "auto",
      display: "block"
    }
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      gap: "1.75rem",
      marginLeft: "1rem"
    }
  }, nav.map(n => /*#__PURE__*/React.createElement("a", {
    key: n,
    href: "#",
    onMouseEnter: () => setOpen(n),
    onMouseLeave: () => setOpen(null),
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "0.9375rem",
      fontWeight: 500,
      color: open === n ? "var(--fast)" : "var(--cream)",
      transition: "color .15s"
    }
  }, n))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: "auto"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "sm",
    as: "a",
    href: "#contact"
  }, "Talk to an Advisor")))));
}
window.SiteHeader = SiteHeader;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SiteHeader.standalone.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.TextLink = __ds_scope.TextLink;

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Blockquote = __ds_scope.Blockquote;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Textarea = __ds_scope.Textarea;

})();
