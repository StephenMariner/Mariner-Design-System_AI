# Mariner Design System — project notes

## Writing content (brand voice, tone, editorial & compliance)
Whenever a request requires **writing or editing copy** — any headline, body, email,
social, bio, presentation text, web copy, CTA label, etc. — first read
**`uploads/Mariner_Claude_Instructions.md`** and follow it. It is the authoritative
source for Mariner's brand voice ("Let's Go!"), tone, compliance do/don't language,
editorial/AP style rules, audience personas, and approved boilerplate. Key reminders
(the file governs in full):
- Voice is direct, confident, approachable, honest — never patronizing, cocky, or brash;
  the audience is "quiet wealth." Avoid distant-future clichés (sailboats, sunsets,
  "someday").
- **Compliance:** no absolute/superlative/promissory claims; no guaranteed outcomes.
  Apply the approved substitutions (every→your, experts→expertise, leading→remove, etc.).
  Use "Mariner" in market-facing copy, "Mariner Wealth Advisors" in legal/disclosure
  contexts. Sourced claims need footnotes; flag missing disclosures.
- **Editorial:** sentence case for headlines/subheads/subject lines; spell out "and"
  (no "&"); "more than/less than" for numbers; spell out one–nine, numerals for 10+;
  audience-dependent advisor term (Financial Advisor for INST/1099, Wealth Advisor
  otherwise).
- **Never invent** statistics, rankings, AUM figures, or dates — flag for human review.
- Note this is a distillation; where a fuller source exists it takes precedence.

## Presentations
When the request involves designing a slide deck, use the Mariner PowerPoint template
**`PPT_Deck_Template_Design (4).pptx`** (in `uploads/`; a tooling-safe, paren-free
duplicate lives alongside it as `uploads/deck_template.pptx`) as the design reference:
match its theme, fonts, colors, and slide layouts, and build the new slides on those
layouts. It is a 72-slide, 16:9 Mariner-branded deck.

- **Build and lay out the full presentation first**, and confirm it's complete and
  correct, before removing anything.
- Once the new deck is finished, the delivered file should contain **only** the slides
  built for this presentation. Remove any of the template's original sample/placeholder
  slides. Do **not** delete the slide masters or layouts — those carry the design and
  must stay.
- The template's theme ships stock Office fonts (Calibri/Arial) and the default Office
  color scheme; the Mariner look lives in the slide content, not the theme.
- If the template isn't a fit for what's being asked, design from scratch rather than
  forcing content into it.

### Fonts (PowerPoint decks)
When drafting a PowerPoint (.pptx), use these fonts:
- **Titles / slide headers → Georgia**
- **Subheaders → Arial Bold**
- **Body / bullet copy → Arial (regular)**

These are system-safe faces installed on virtually every machine, so the deck renders
correctly for any recipient without font embedding. Georgia and Arial are the brand
faces everywhere — HTML, PDF and .pptx alike — so decks need no font substitution.

### Slide headers — uniform size and case (slides only)
- **One size for every main slide header on content slides.** Pick a single Georgia size
  for the deck's main slide headers and use that exact size on every content slide — no
  per-slide scaling to fit, no "just a bit smaller" on the busy slides. Set it once on the
  layout/master so all headers inherit it. If a header won't fit at that size, shorten the
  header, widen the placeholder, or split the slide — never shrink the type.
- **Exception — cover and transition slides run larger.** The cover/title slide and section
  divider (transition) slides get a deliberately larger Georgia size than the content-slide
  header, for hierarchy. Two additional sizes at most: one for the cover, one for section
  dividers (the cover may be the largest, or the two may share a size). Set each on its own
  layout and apply it consistently — every divider in the deck uses the same size as every
  other divider. This is the only permitted deviation from the single-header-size rule.
- **Main slide headers are Title Case in every instance**, on every slide, including
  section dividers and the cover — the size exception above does not change the casing
  rule. This is a slides-only exception to the sentence-case headline rule.
- **Every other header is sentence case** — subheaders, in-slide headers, card/callout
  titles, chart and table titles, kicker lines under the main header.
- **Eyebrow headers are ALL CAPS.**
- Before delivering, sweep the deck: confirm all content-slide main headers share one font
  size, the cover and dividers use their own larger sizes consistently, all main headers are
  Title Case, all secondary headers are sentence case, and all eyebrows are all caps.

### Brand colors — theme-level enforcement
- **Every PPT deck must use the official brand colors, applied at the theme level**
  (Slide Master → theme colors), not manually shape-by-shape — so every new slide,
  placeholder, chart, and SmartArt object inherits brand colors by default.
- Map the brand palette to the theme slots explicitly so anything referencing a theme
  color resolves to a brand color. No slot may hold an off-brand Office default (stock
  blue/orange). Suggested mapping (values in `tokens/colors.css`):
  - Text/Background — Dark 1 = Black `#000000`, Light 1 = White `#FFFFFF`,
    Dark 2 = Access `#2294BD`, Light 2 = Cream `#F0E6DD`.
  - Accent 1 = Access `#2294BD`, Accent 2 = Rust `#D9532B`, Accent 3 = Fast `#FAA51A`,
    Accent 4 = Cream `#F0E6DD`, Accent 5 = Black `#000000`, Accent 6 = White `#FFFFFF`.
- **Charts, tables, and diagrams pull from the theme accents** — never PowerPoint's
  default color cycle. If an object comes in with default colors, remap it to the theme.
- **Write the brand palette into the theme on every .pptx/.ppt export.** Exporting is not
  complete until the theme itself carries brand colors: write the brand hex values into
  the theme color scheme in the file (`ppt/theme/theme1.xml` — `dk1`/`lt1`/`dk2`/`lt2` and
  `accent1`–`accent6` per the mapping above) rather than relying on the source template or
  on shape-level fills. Verify after export that no theme slot still holds an Office
  default; if any does, rewrite the theme and re-export. This applies to every export path
  — new decks, restyles of a provided source, and HTML→PPTX conversions alike.

### No off-brand color
- No slide may introduce a color outside the official palette, including tints/shades,
  unless that tint/shade is a defined step within the brand system (`tokens/colors.css`).
- If a referenced source uses off-brand colors, **replace them with the nearest
  brand-palette equivalent** rather than preserving the source color — a styling override,
  consistent with the corner-radius rule, that takes priority over source fidelity.

## Boxes & Containers
### Outlines on white boxes
- A white box placed on a cream or colored background must have **no outline or stroke**.
  The contrast between the white fill and the background defines the edge; an added border
  reads as clutter and doubles the boundary.
- Outlines/strokes on white boxes are only permitted when the box sits on a white (or
  near-white) background where fill alone can't separate it from the canvas.

### Corner radius
- **No boxed content has rounded edges in final output.** All boxes, cards, containers,
  image frames, and callouts use square (90°) corners. The `--radius-*` tokens are all `0`.
- If a referenced source has rounded edges, **square them off** — match the content and
  styling of the source but override its corner radius to 0.
- This applies regardless of the source's original treatment; square corners take priority
  over source fidelity for this attribute specifically.

## Source fidelity (restyle & re-layout operations)
When a source is provided to be restyled or re-laid-out — a PPTX, DOCX, or a URL —
treat its **content as fixed and its visual design as the only thing you may change.**
The task is to change how the material *looks*, never what it *says*.

- **Copy every piece of content verbatim.** Preserve exact wording, spelling,
  capitalization, punctuation, numbers, dates, units, symbols, and the order content
  appears in. Do not paraphrase, summarize, expand, condense, rewrite, "improve,"
  translate, or reorder. Reproduce the source's structure — headings, list nesting,
  slide/section sequence, table rows and columns — as-is.
- **Only visual styling may change.** Fonts, colors, sizes, spacing, alignment,
  backgrounds, icons, imagery, and arrangement are yours to design for impact.
  Emphasis (bold, weight, size, color) is allowed *only when it doesn't alter meaning.*
- **Never silently:** drop/cut/truncate content to make it fit (reflow, resize, or split
  instead); add content not in the source (no invented headlines, taglines, stats,
  sample data, filler, or lorem-ipsum); fix apparent typos, grammar, or factual errors
  (flag them, leave the original); round/reformat/"clean up" numbers, dates, or figures
  (chart and table values must match exactly); or merge, split, or re-sequence
  slides/sections.
- **Text baked into an image stays in the image** — preserve as-is and note it; do not
  retype, alter, or re-typeset it as editable text.
- **Template prompt text is not content.** Empty-placeholder prompts (e.g. "Click to
  edit…") are layout artifacts, not source content — do not copy them into the output.
- **Em dash spacing is styling, not content.** The Mariner em dash override applies to
  copied source material too: reset any spaced em dash (` — `) to tight (`—`), the same way
  corner radius and off-brand color get overridden. This is the ONLY verbatim-copy
  exception on the wording side — it changes spacing around the character, never the
  characters, words, or punctuation marks themselves. Do not convert hyphens or en dashes
  to em dashes, or vice versa, and do not otherwise "fix" the source's punctuation.
- **When something won't fit,** never resolve it by cutting or summarizing. Enlarge the
  container, reduce the font within reason, reflow, or split across additional
  slides/pages — and if none of that works, stop and ask.
- **Changing content requires an explicit request.** The default is 100% verbatim. Only
  alter, trim, rewrite, or reorder when the user specifically asks — and then change only
  what they asked for.
- **Before declaring done, run a fidelity check:** (1) extract the output's text and
  compare against the source; (2) confirm nothing was added, dropped, reworded, or
  reordered; (3) confirm every number, date, name, and label matches exactly; (4) confirm
  slide/section order and hierarchy match; (5) report anything that couldn't be preserved
  (e.g. text inside images), and why.

## Page margins — 0.5in is the default
Every document, PDF, and printable page gets **0.5in margins on all four sides** unless the
user asks for something else. This is the system default (`--print-margin`), not a starting
suggestion.
- **Use the token.** Set page padding from `var(--print-margin)` rather than typing a value,
  so a future change to the token propagates. Never hardcode `0.75in`, `1in`, or a browser
  default.
- **All four sides equal.** Top, right, bottom and left are the same 0.5in. Running headers
  and footers sit inside that margin box, not outside it.
- **Consistent through a piece.** Every page of a multi-page document uses the same margin —
  covers, interior pages, and back pages alike. Full-bleed backgrounds may run to the page
  edge, but the *text* inside them still respects the 0.5in inset.
- **Column gutters** are `--print-gutter` (0.375in) and are also consistent throughout.
- Never resolve an overflow by shrinking the margin. Reflow, reduce type within reason, or
  add a page — and if none of that works, stop and ask.

## InDesign-safe layout for print artifacts
When a Mariner document is destined for PDF export and InDesign hand-off, do NOT build
multi-item lists, cards, or column layouts with CSS grid or side-by-side flexbox. A
browser-exported PDF has no concept of grid or flex — each cell becomes a separately
positioned text frame, so a grid of flex cells (number + title + body per cell) imports
into InDesign as dozens of disconnected boxes that cannot be reconciled into an editable
list.

- **Flow, don't grid.** Build lists as normal block-level paragraphs in document order.
  For multiple columns, use real CSS columns (`column-count` / `column-gap`) on the
  container — never `display:grid` or a row of flex `<div>`s.
- **One paragraph per item.** Collapse each list item into a single `<p>` with inline
  emphasis (`<span>`/`<strong>` for the number and bold lead-in), rather than stacking
  separate number/title/body `<div>`s. Fewer nested containers = fewer fragmented frames.
- **Reserve grid/flex for purely visual, non-reflowing arrangements** (e.g. a header row
  with a logo and eyebrow), not for text runs meant to read as a continuous list.
- **Set expectations:** even flattened, browser PDFs import as positioned text, not a
  threaded InDesign story; columns may land as separate blocks. Each item stays intact and
  editable, but heavy InDesign rework of a list is most reliable rebuilt natively there
  using this copy and styles.

## Fonts — Georgia and Arial only
The Mariner faces are **Georgia** (serif — titles, display, editorial) and **Arial**
(sans — headers, body, UI, eyebrows). Both are system fonts present on virtually every
machine, so nothing is self-hosted and no webfont ever loads. Source Serif 4 / Source
Serif Pro and Inter / Inter Tight are retired — never reintroduce them.
- **Georgia is the serif; Arial is the sans, in every medium** — HTML, PDF, and .pptx.
  `--font-serif` leads with `Georgia`, `--font-sans` leads with `Arial`. Never load a
  Google-hosted or self-hosted webfont in their place.
- **Audit every `font-family`.** Everything resolves to `var(--font-sans)` or
  `var(--font-serif)` — no stray `-apple-system`, Helvetica, Calibri, or Times as the
  PRIMARY family on any element. Fallbacks are fine only after the real family.
- **InDesign relinks by EXACT family name.** `Georgia` and `Arial` are the exact
  installed desktop names, so a placed PDF relinks with no reflow.
- **Export:** Save as PDF (vector, live text), "Selection only" off. On import, a subset
  prefix (e.g. `ABCDE+Georgia`) relinks via Type ▸ Find/Replace Font, because the base
  name matches.
