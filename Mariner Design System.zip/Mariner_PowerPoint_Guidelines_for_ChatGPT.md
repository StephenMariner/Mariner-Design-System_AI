# Mariner — PowerPoint and slide guidelines

> **How to use this file:** Upload or paste it into ChatGPT (Project instructions, a Custom
> GPT's knowledge, or the start of a conversation) whenever the task involves building,
> restyling, or editing a Mariner PowerPoint deck. Treat every rule below as binding.
> Where a rule conflicts with general AP style, PowerPoint convention, or a source file's
> original design, **this file wins.** If you cannot follow a rule, stop and say so rather
> than quietly deviating.
>
> Also attach the Mariner PowerPoint template (`PPT_Deck_Template_Design (4).pptx`) when
> you have it — it is the design reference for theme, fonts, colors, and layouts.

---

## 1. The two outlier rules — read these first

These are the rules most often gotten wrong, because each one overrides a convention you
would otherwise follow by default.

### 1a. Em dashes are set tight — no spaces (overrides AP style)

- Set every em dash **flush against the surrounding words**, with no space before or
  after: `like this—no spaces`.
- AP style calls for spaces around an em dash. **Mariner does not.** This is a deliberate,
  Mariner-specific override and it applies everywhere: slide headers, subheads, body copy,
  bullets, callouts, chart titles, footnotes, speaker notes.
- **It also applies to copied source material.** When you are restyling an existing deck,
  document, or page and reproducing its text verbatim, em dash *spacing* counts as styling,
  not content — reset any spaced em dash (` — `) to tight (`—`). This is the **only**
  wording-side exception to verbatim copying (see §7), and it is narrow: it changes the
  spacing around the character only.
- Do **not** convert hyphens or en dashes into em dashes, or em dashes into anything else,
  and do not otherwise "fix" the source's punctuation.

### 1b. Fonts — Georgia and Arial

The Mariner brand faces are **Georgia** (serif) and **Arial** (sans), in every medium —
HTML, PDF and PowerPoint alike. In PowerPoint, use:

| Element | Font |
| --- | --- |
| Titles / main slide headers | **Georgia** |
| Subheaders | **Arial Bold** |
| Body and bullet copy | **Arial** (regular) |

Rationale: Georgia and Arial are system-safe faces installed on virtually every machine, so
the deck renders correctly for any recipient without font embedding. Never substitute
Calibri, Times New Roman, Helvetica, Inter, or Source Serif into a deck.

---

## 2. Slide headers — one size, and the case rules

### One size for every main slide header on content slides
- Pick a single Georgia size for the deck's main slide headers and use **that exact size on
  every content slide.** No per-slide scaling to fit. No "just a bit smaller" on the busy
  slides. No PowerPoint autofit shrinking the title.
- Set it once on the slide layout/master so all headers inherit it.
- If a header won't fit at that size: **shorten the header, widen the placeholder, or split
  the slide.** Never shrink the type.

### Exception — cover and transition slides run larger
- The cover/title slide and section divider (transition) slides get a deliberately **larger**
  Georgia size than the content-slide header, for hierarchy.
- **Two additional sizes at most:** one for the cover, one for section dividers. The cover
  may be the largest, or the cover and dividers may share a size.
- Set each on its own layout and apply it consistently — every divider in the deck uses the
  same size as every other divider.
- This is the **only** permitted deviation from the single-header-size rule.

### Case rules (slides only)
- **Main slide headers are Title Case in every instance** — on every slide, including
  section dividers and the cover. The size exception above does not change the casing rule.
  This is a slides-only exception to Mariner's general sentence-case headline rule.
- **Every other header is sentence case** — subheaders, in-slide headers, card and callout
  titles, chart and table titles, kicker lines under the main header.
- **Eyebrow headers are ALL CAPS.**

### Pre-delivery header sweep
Before delivering any deck, confirm:
1. All content-slide main headers share one font size.
2. The cover and dividers use their own larger sizes, consistently.
3. All main headers are Title Case.
4. All secondary headers are sentence case.
5. All eyebrows are all caps.

---

## 3. Brand color — enforced at the theme level

### The official 2024 palette

| Role | Name | Hex | Notes |
| --- | --- | --- | --- |
| Primary | Black | `#000000` | May be a full-bleed background |
| Primary | White | `#FFFFFF` | May be a full-bleed background |
| Primary | Cream | `#F0E6DD` | May be a full-bleed background |
| Primary | Access | `#2294BD` | May be full-bleed; use cautiously to preserve its importance |
| Accent | Rust | `#D9532B` | Use sparingly; **never** a full-bleed background |
| Accent | Fast | `#FAA51A` | Use sparingly; **never** a full-bleed background |

Cream is the text color on black backgrounds.

### Apply color through the theme, not shape by shape
- **Every deck must use the brand colors applied at the theme level** (Slide Master → theme
  colors), so every new slide, placeholder, chart, and SmartArt object inherits brand colors
  by default. Do not hand-fill shapes as your primary color strategy.
- Map the palette to the theme slots explicitly, so anything referencing a theme color
  resolves to a brand color. **No slot may hold an off-brand Office default** (stock blue,
  stock orange):
  - **Text/Background:** Dark 1 = Black `#000000` · Light 1 = White `#FFFFFF` ·
    Dark 2 = Access `#2294BD` · Light 2 = Cream `#F0E6DD`
  - **Accent 1** = Access `#2294BD` · **Accent 2** = Rust `#D9532B` ·
    **Accent 3** = Fast `#FAA51A` · **Accent 4** = Cream `#F0E6DD` ·
    **Accent 5** = Black `#000000` · **Accent 6** = White `#FFFFFF`
- **Charts, tables, and diagrams pull from the theme accents** — never PowerPoint's default
  color cycle. If an object arrives with default colors, remap it to the theme.

### Write the palette into the theme on every export
Export is not complete until the theme file itself carries brand colors. Write the brand hex
values into the theme color scheme in the file (`ppt/theme/theme1.xml` — `dk1`/`lt1`/`dk2`/
`lt2` and `accent1`–`accent6`, per the mapping above) rather than relying on the source
template or on shape-level fills. **Verify after export** that no theme slot still holds an
Office default; if any does, rewrite the theme and export again. This applies to every path
— new decks, restyles of a provided source, and HTML → PPTX conversions alike.

### No off-brand color
- No slide may introduce a color outside the palette above, including tints and shades,
  unless that tint/shade is a defined step in the Mariner design system.
- If a referenced source uses off-brand colors, **replace them with the nearest brand
  equivalent** rather than preserving the source color. This is a styling override that
  takes priority over source fidelity.

---

## 4. Boxes, cards and containers

- **Square corners, always.** No boxed content has rounded edges in final output — boxes,
  cards, containers, image frames, callouts and tables all use square (90°) corners. If a
  referenced source has rounded corners, square them off. Square corners take priority over
  source fidelity for this attribute specifically.
- **No outline on a white box over a cream or colored background.** The fill contrast defines
  the edge; adding a border doubles the boundary and reads as clutter. Outlines on white
  boxes are permitted only when the box sits on a white or near-white background where fill
  alone can't separate it from the canvas.

---

## 5. Working from the Mariner template

- Use `PPT_Deck_Template_Design (4).pptx` as the design reference: match its theme, fonts,
  colors and slide layouts, and build new slides **on those layouts.** It is a 72-slide,
  16:9 Mariner-branded deck.
- **Build and lay out the full presentation first**, and confirm it is complete and correct,
  before removing anything.
- Once the deck is finished, the delivered file should contain **only** the slides built for
  this presentation. Remove the template's original sample/placeholder slides. **Do not
  delete the slide masters or layouts** — those carry the design and must stay.
- The template's theme ships stock Office fonts and the default Office color scheme; the
  Mariner look lives in the slide content. Fix the theme per §3 regardless.
- **Empty-placeholder prompt text is not content.** Strings like "Click to edit Master text
  styles" are layout artifacts — never copy them into output slides.
- If the template genuinely isn't a fit for what's being asked, design from scratch rather
  than forcing content into it.

---

## 6. Copywriting on slides

Slide text follows Mariner's voice, compliance and editorial rules. The essentials:

**Voice — "Let's Go!"**
- Direct, confident, approachable, honest, dependable, empowering. Never patronizing, cocky,
  judgmental, blunt, know-it-all or overbearing.
- The audience is **quiet wealth** — speak like an expert, never brash or boisterous.
- Focus on solving present complexity, not distant dreams. Avoid industry clichés of the
  far-off future (no sailboats, sunsets, "someday" language).

**Compliance**
- No absolute, superlative or promissory claims. No guaranteed outcomes, returns or success.
- Substitutions: every → your · experts → expertise · leading → (remove) · and similar.
- Use **Mariner** in market-facing copy; **Mariner Wealth Advisors** in legal and disclosure
  contexts.
- Sourced claims (statistics, rankings, third-party data) require footnotes.
- **Never invent** statistics, rankings, AUM figures or dates — flag them for human review.
- Flag any deck that appears to need standard disclosures but doesn't have them.

**Editorial**
- Serial (Oxford) comma: **omit it** per AP style — "tax, estate and trust" — using it only
  to avoid ambiguity or in lists with internal commas.
- Em dashes: tight, no spaces (see §1a).
- Write out "and" — never "&" (exceptions: proper names like Procter & Gamble, and M&A).
- "More than / less than" for numbers, never "over / under."
- Spell out one through nine; numerals for 10 and up. Use "to" for ranges. No st/nd/rd/th
  after dates.
- Advisor term is audience-dependent: **Financial Advisor** for institutional/1099 audiences,
  **Wealth Advisor** otherwise.
- Sentence case for all headlines and subheads — **except** main slide headers, which are
  Title Case (§2), and eyebrows, which are all caps.

---

## 7. Restyling an existing deck — content is fixed

When a source deck, document or page is provided to be restyled or re-laid-out, treat its
**content as fixed and its visual design as the only thing you may change.** Change how the
material looks, never what it says.

- **Copy every piece of content verbatim** — exact wording, spelling, capitalization,
  punctuation, numbers, dates, units, symbols, and the order content appears in. Reproduce
  the structure as-is: headings, list nesting, slide sequence, table rows and columns.
- **Only visual styling may change** — fonts, colors, sizes, spacing, alignment, backgrounds,
  icons, imagery, arrangement. Emphasis (bold, weight, size, color) is allowed only when it
  doesn't alter meaning.
- **Never silently:** drop, cut or truncate content to make it fit; add content that isn't in
  the source (no invented headlines, taglines, stats, sample data or filler); fix apparent
  typos, grammar or factual errors (flag them, leave the original); round or reformat numbers,
  dates or figures (chart and table values must match exactly); or merge, split or re-sequence
  slides.
- **Text baked into an image stays in the image** — preserve as-is and note it. Do not retype
  or re-typeset it as editable text.
- **When something won't fit,** never resolve it by cutting or summarizing. Enlarge the
  container, reflow, reduce body copy size within reason, or split across additional slides —
  and if none of that works, stop and ask. Remember main slide headers never shrink (§2).
- **Three styling overrides do apply to copied material:** corner radius → square (§4),
  off-brand color → nearest brand equivalent (§3), and spaced em dash → tight em dash (§1a).
- **Changing content requires an explicit request.** The default is 100% verbatim.
- **Before declaring done, run a fidelity check:** extract the output's text and compare it
  against the source; confirm nothing was added, dropped, reworded or reordered; confirm every
  number, date, name and label matches exactly; confirm slide order and hierarchy match; and
  report anything that couldn't be preserved (such as text inside images), and why.

---

## 8. Final delivery checklist

1. **Fonts:** Georgia titles, Arial Bold subheaders, Arial body. No Calibri, no brand
   webfonts, no stray faces.
2. **Header size:** one size across all content slides; cover and dividers larger and
   internally consistent; no autofit shrinking.
3. **Header case:** main headers Title Case, all other headers sentence case, eyebrows all
   caps.
4. **Theme colors:** brand hex values written into the theme; no Office defaults in any slot;
   charts and tables using theme accents.
5. **Palette discipline:** no off-brand colors or undefined tints; Rust and Fast used sparingly
   and never full-bleed.
6. **Containers:** square corners everywhere; no outlines on white boxes over cream or color.
7. **Em dashes:** every one tight, no spaces — including in copied source text.
8. **Punctuation and numbers:** no serial comma, "and" spelled out, more than/less than,
   one–nine spelled out.
9. **Compliance:** no absolute or promissory claims; no invented figures; correct entity name;
   footnotes and disclosures present or flagged.
10. **Template hygiene:** only this presentation's slides remain; masters and layouts intact;
    no placeholder prompt text.
