# Mariner Design System

Design system for the **Mariner** brand (Mariner Wealth Advisors) — a national
registered investment advisor offering wealth planning, investment management, tax,
estate, trust, retirement-plan and insurance services to individuals, businesses and
plan sponsors. Voice is confident, warm, plain-spoken. The visual identity balances
**warm and editorial**: Black, Cream, White and Access blue as primaries, with Rust
and Fast orange as sparing accents, set in **Georgia** (titles) and
**Arial** (headers, body, UI).

## Sources
- `uploads/Mariner_Color Palette_2024.pdf` — **official color palette** (exact hex/Pantone + usage rules). Tokens match it exactly.
- `uploads/Mariner_Logo_Black.png`, `Mariner_Logo_Cream.png`, `Mariner_Logo_White.png` — **official wordmark**, copied to `assets/`.
- Brand collateral (layout, margins, tone reference):
  - `uploads/Wealth preservation.pdf` — elevated guide (asymmetric grids, full-bleed cover)
  - `uploads/The 2026 retirement participant.pdf` — elevated white paper
  - `uploads/Advisor Recruitment_Sweet Spot White Paper.pdf` — elevated white paper
  - `uploads/Financial Wellness Sponsor Plan 2-pager.pdf` — **standard** article/white-paper format
- Public marketing site `https://www.marinerwealthadvisors.com/` (structure/copy reference).

## Color (official 2024 palette)
- **Primary:** Black `#000000`, Cream `#F0E6DD`, White `#FFFFFF`, Access `#2294BD`.
  All four may be **full-bleed backgrounds**. Use Access **cautiously** to preserve its
  importance in the identity.
- **Accent:** Rust `#D9532B`, Fast `#FAA51A`. Use **sparingly**; **never full-bleed**
  backgrounds in print or digital. Live in short-form captions, labels, CTAs, and as
  wayfinding.
- **Text:** Black and cream are primary text colors; white when higher contrast is
  needed. **Access only on headlines/large text, never body copy.**
- Grays and tints in `tokens/colors.css` marked "derived" are working values for UI
  states, not official brand colors.

## Typography
- **Titles:** Georgia **Regular** (never bolded). **Action words may be italicized** —
  e.g. *well-planned*, *meaningful*.
- **Headers:** Arial **Regular**, colored **Access or Rust** per the color chart.
- **Body copy:** Arial Regular — **10pt in print** (`--print-body`), 16px on screen.
- Overlines/CTA labels (eyebrows): Arial **Bold**, uppercase, +0.14em tracking — all-caps eyebrow text is bold in every instance.
- Both faces are **system fonts** — no webfonts are loaded and nothing is self-hosted.

## PDF & InDesign export
When a Mariner artifact is exported to PDF (browser print) and imported into Adobe
InDesign, text should stay live and matchable. Both brand families are **system fonts** —
`Georgia` and `Arial` — installed on every export machine and on every designer's
machine, so Chrome embeds the genuine outlines under their real names and InDesign
relinks them by exact family name. Guidelines:
1. **Use the token stacks** — `var(--font-serif)` (Georgia) and `var(--font-sans)`
   (Arial). Never load a webfont, hosted or self-hosted, in their place.
2. In the print dialog choose **"Save as PDF"** (vector, live text), not "Print to
   image"; keep "Selection only" off so all fonts embed.
3. On import into InDesign, if a font shows as a subset, use **Type ▸ Find/Replace
   Font** to relink to Georgia / Arial — names match, so it reflows cleanly with no
   layout shift.

## Document design (from 2024–26 collateral)
Two registers, ebbing and flowing around the same core standards:
- **Elevated** (guides, thought-leadership white papers — e.g. Wealth Preservation,
  The 2026 Retirement Participant, The Sweet Spot): **asymmetric grids for large
  impact moments** — oversized regular-weight serif titles with italic action words,
  full-bleed black/cream/access pages, generous white space, off-center text blocks,
  big stats. Running footer with document title + page number; covers full-bleed with
  the wordmark.
- **Standard** (articles, 2-pagers, anything form-like — e.g. Financial Wellness
  2-pager): **reserved and symmetrical** — even two-column body text at 10pt,
  consistent `--print-margin` (0.5in) page margins, logo in header, and a footer
  with `mariner.com` + full legal disclosure block in `--print-caption` size.
- Headers/footers take liberties between internal pages (minimal running footers) and
  covers/back pages (full branding + disclosures) — keep margins and column gutters
  (`--print-gutter`) consistent throughout a piece.

## Content fundamentals (voice & tone)
Second-person, direct, benefit-led. *"You've built momentum."* *"Where your wealth
goes next is up to you."* Short declarative sentences; deliberate fragments for
rhythm. Sentence-case titles; UPPERCASE only for overlines/CTA labels. Finance
concepts stated plainly; careful hedged compliance language in body ("may", "can",
"is designed to") and formal disclosure blocks. Stats quoted precisely with numbered
footnotes. Pull quotes with named attribution (name, CREDENTIALS, ROLE in caps).
**No emoji, ever.**

## Iconography
Type- and photography-led; no icon font or SVG library in the sources. Small glyphs
are restrained Unicode (› chevron for CTA links, + for accordions). Checklists (□)
appear in elevated pieces. If you need a full icon set, choose a thin-stroke set
(e.g. Lucide) and document it here — none has been added.

## Index / manifest
**Root** — `styles.css` (consumers link this; `@import` list only), `readme.md`, `SKILL.md`
- `tokens/` — `colors.css`, `typography.css` (incl. print scale),
  `spacing.css` (incl. print margins), `radius.css`, `shadow.css`, `base.css`
- `assets/` — **official logos** (Black/Cream/White PNG)
- `uploads/` — source PDFs (palette, logos, four collateral pieces)

**Components** (namespace `window.MarinerDesignSystem_43493c`)
- actions/ — **Button**, **TextLink**
- forms/ — **Input**, **Textarea**, **Select**, **Checkbox**, **Radio**
- content/ — **Eyebrow**, **Card**, **Badge**, **Stat**, **Blockquote**, **Divider**, **Accordion**

**Foundation cards** (`guidelines/`) — Colors (Primary, Accent, Text rules, Derived
grays, Status), Type (Serif Titles, Title Scale, Headers & Body, Eyebrow & UI),
Spacing (Scale, Radius & Shadow), Brand (Logo, Voice & Tone, Section Treatments,
Document Grids).

**UI kits** (`ui_kits/website/`) — marketing Homepage recreation with interactive
contact form.
