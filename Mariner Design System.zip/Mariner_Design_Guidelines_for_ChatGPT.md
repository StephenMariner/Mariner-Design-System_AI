# Mariner — design guidelines

> **How to use this file:** Upload or paste it into ChatGPT (Project instructions, a Custom
> GPT's knowledge, or the start of a conversation) whenever the task involves designing a
> Mariner artifact — a document, white paper, one-pager, flier, web page, email, social
> graphic, or any other visual deliverable. Treat every rule below as binding. Where a rule
> conflicts with general design convention, AP style, or a source file's original design,
> **this file wins.** If you cannot follow a rule, stop and say so rather than quietly
> deviating.
>
> **For PowerPoint decks, use the companion file** `Mariner_PowerPoint_Guidelines_for_ChatGPT.md`
> instead — slides have their own header-size, casing, and theme-color rules that differ from
> the ones here.
>
> **Assume every PDF is headed into Adobe InDesign.** §7 governs how the page must be built
> for that hand-off — live text, flowing paragraphs instead of grids, explicit page geometry.
> Design for it from the start; it is not something that can be fixed after export.

---

## 1. The four outlier rules — read these first

These are the rules most often gotten wrong, because each one overrides a convention you
would otherwise follow by default.

### 1a. Fonts are Georgia and Arial — nothing else

- **Georgia** is the serif: titles, display type, editorial moments.
- **Arial** is the sans: headers, body copy, UI, eyebrows, labels, captions.
- Both are system fonts installed on virtually every machine, so **no webfont ever loads** —
  no Google Fonts, no self-hosted files. Never substitute Calibri, Times New Roman,
  Helvetica, Inter, Source Serif, or a "similar" face.
- This applies in every medium: HTML, PDF, print, email, and PowerPoint alike.
- Titles are **Regular weight** Georgia — never bolded. Action words inside a title *may*
  be italicized (*well-planned*, *meaningful*).

### 1b. Em dashes are set tight — no spaces (overrides AP style)

- Set every em dash **flush against the surrounding words**: `like this—no spaces`.
- AP style calls for spaces around an em dash. **Mariner does not.** This applies everywhere:
  headlines, subheads, body copy, bullets, callouts, captions, footnotes.
- **It also applies to copied source material.** When restyling an existing document or page
  and reproducing its text verbatim, em dash *spacing* counts as styling, not content — reset
  any spaced em dash (` — `) to tight (`—`). This is the **only** wording-side exception to
  verbatim copying (see §8).
- Do **not** convert hyphens or en dashes into em dashes, or vice versa.

### 1c. Nothing has rounded corners

- Every box, card, container, image frame, callout, button, input, and table cell uses
  **square (90°) corners**. Corner radius is `0` throughout the system.
- If a reference or source design has rounded edges, **square them off.** Match its content
  and layout, override its radius.
- The only exception is a genuinely circular element (an avatar or a dot), which is a shape,
  not a radius.

### 1d. White boxes on colored backgrounds get no outline

- A white box sitting on cream, black, or Access blue has **no border or stroke.** The fill
  contrast defines the edge; adding a border doubles the boundary and reads as clutter.
- Outlines on white boxes are permitted **only** when the box sits on white or near-white,
  where fill alone cannot separate it from the canvas.

---

## 2. Color — the official 2024 palette

**Primary — all four may be used as full-bleed backgrounds:**

| Color | Hex | Pantone |
| --- | --- | --- |
| Black | `#000000` | Black 2 C |
| White | `#FFFFFF` | — |
| Cream | `#F0E6DD` | 9043 C |
| Access blue | `#2294BD` | 2200 C |

**Accent — use sparingly, NEVER full-bleed (print or digital):**

| Color | Hex | Pantone |
| --- | --- | --- |
| Rust | `#D9532B` | 7579 C |
| Fast orange | `#FAA51A` | 130 C |

Rules:
- Use **Access cautiously** — its scarcity is what gives it importance in the identity.
- Accents live in short-form captions, labels, CTAs, rules, and wayfinding — not in fields
  of color.
- **Text:** Black and Cream are the primary text colors; White where higher contrast is
  needed. **Access may be used on headlines and large text, never on body copy.**
- Cream is the text color on black backgrounds (not white).
- **No off-brand color, ever** — including tints and shades you invent. If a source or
  reference uses an off-brand color, **replace it with the nearest brand equivalent** rather
  than preserving it. Working grays (`#1A1A1A` → `#EFEFEF`) exist for UI states and borders
  only; they are not brand colors and never carry brand meaning.
- Cap a single piece at **one or two background colors** total.

---

## 3. Typography

| Role | Face | Weight | Notes |
| --- | --- | --- | --- |
| Titles / display | **Georgia** | Regular (400) | Never bold. Action words may be italic. |
| Headers / subheads | **Arial** | Regular | Colored **Access or Rust** per the color rules |
| Body copy | **Arial** | Regular | **10pt in print**, 16px on screen |
| Eyebrows / overlines / CTA labels | **Arial** | **Bold** | ALL CAPS, +0.14em letter-spacing |
| Captions / footnotes / disclosures | **Arial** | Regular | 7.5pt in print |

**Screen scale (px):** display 68 / 52 / 40 · H1 44 · H2 32 · H3 24 · H4 20 · lead 22 ·
body 16 · small 15 · caption 13 · eyebrow 12.

**Print scale:** title 30pt (larger on covers) · header 12pt · body 10pt · caption 7.5pt.
Print body leading 1.45.

**Case:** sentence case for all headlines and subheads (capitalize the first word and proper
nouns only; capitalize the first word after a colon). ALL CAPS is reserved for eyebrows and
CTA labels. Never title-case a headline in a document or web page. *(Slides are the
exception — see the PowerPoint file.)*

**Line height:** 1.08 tight (display) · 1.2 snug · 1.5 normal · 1.65 relaxed (long-form body).

**Minimum sizes:** 12pt in print documents; never below 14px on screen for body text.

---

## 4. Layout and spacing

- **Spacing scale, 4px base:** 4 · 8 · 12 · 16 · 24 · 32 · 48 · 64 · 96 · 128. Use the scale;
  don't invent intermediate values.
- **Page margin (print):** **0.5in on all four sides — the default for every document, PDF,
  and printable page** unless the user asks for something else. Same margin on every page of
  a piece, covers and interiors alike; running headers and footers sit inside the margin box.
  Full-bleed backgrounds may run to the page edge, but text inside them still respects the
  0.5in inset. Never hardcode 0.75in or 1in, and never shrink the margin to fix an overflow —
  reflow, reduce type within reason, or add a page. **Column gutter:** 0.375in, also
  consistent throughout.
- **Reading measure:** 760px / roughly 56–65 characters for long-form body copy. Content
  container max 1200px on web.
- **Section rhythm:** 96px vertical padding between web sections.

Two document registers, both built on the same core standards:

- **Elevated** (guides, thought-leadership white papers) — **asymmetric grids for big impact
  moments.** Oversized Georgia Regular titles with italic action words, full-bleed
  black/cream/Access pages, generous white space, off-center text blocks, large stats.
  Running footer with document title and page number; cover is full-bleed with the wordmark.
- **Standard** (articles, 2-pagers, anything form-like) — **reserved and symmetrical.** Even
  two-column body at 10pt, consistent 0.5in margins, logo in the header, footer with
  `mariner.com` plus the full legal disclosure block at caption size.

Headers and footers may take liberties between internal pages (minimal running footers) and
covers/back pages (full branding and disclosures) — but margins and gutters stay consistent
throughout a piece.

---

## 5. Logo and imagery

- Use the **official wordmark** only — Black on light backgrounds, Cream on black, White for
  high contrast. Never redraw, re-letter, stretch, recolor, or add effects to it.
- The identity is **type- and photography-led.** There is no icon library. Small glyphs are
  restrained Unicode: `›` for CTA links, `+` for expand/collapse, `□` for checklists in
  elevated pieces. If a full icon set is genuinely needed, use a thin-stroke set and say so.
- **No emoji, ever.**
- Don't illustrate with generated or drawn SVG artwork. Use real photography, or a clearly
  marked image placeholder and ask for the asset.
- Avoid the distant-future clichés the brand rejects: no sailboats, sunsets, beaches, or
  "someday" imagery. The audience is **quiet wealth** — present-tense, grounded, real.

---

## 6. Writing copy (when the task includes words)

Voice is **direct, confident, approachable, honest** — never patronizing, cocky, or brash.
Second person, benefit-led, short declarative sentences, deliberate fragments for rhythm.
Simplify complexity; focus on solving present-day needs, not distant dreams.

**Compliance — no absolute, superlative, or promissory claims.** Approved substitutions:

| Don't use | Use instead |
| --- | --- |
| Every | Your |
| Experts | Expertise |
| Obsessed | Committed |
| Most | Your |
| Leading | Remove entirely |
| World-class | "Our best advice" |
| Next-level | "Meet the needs" framing |

- Never guarantee outcomes, returns, or success. No assurance language.
- Use **Mariner** in market-facing copy; **Mariner Wealth Advisors** in legal and disclosure
  contexts.
- **Never invent** statistics, rankings, AUM figures, or dates. Sourced claims need
  footnotes. Flag anything uncertain — designations, disclosures, AUM, legal language — for
  human review rather than guessing.
- Educational and marketing materials generally require standard disclosures (informational
  purposes only, not individualized advice, investing involves risk). Flag a deliverable that
  appears to be missing them.

**Editorial style** (AP plus Mariner overrides):
- Sentence case for headlines, subheads, email subject lines, and preview text.
- Spell out "and" — never "&".
- "More than" / "less than," not "over" / "under," for numbers.
- Spell out one through nine; numerals for 10 and up.
- Omit the serial comma per AP, except where it prevents ambiguity.
- Advisor term is audience-dependent: **Financial Advisor** for INST/1099 audiences,
  **Wealth Advisor** for client and all other audiences.
- Em dashes tight, per §1b.

---

## 7. PDF output must be InDesign-compatible

**Every PDF Mariner produces is assumed to be headed into Adobe InDesign for finishing.**
Design for that hand-off from the start — it is not a post-processing step, and it constrains
how you build the page. A PDF that looks right but imports as a mess of frames and outlined
type has failed.

### 7a. Text must stay live and relinkable

- Export via **Save as PDF** (vector, live text) — never "Print to image," never a
  screenshot, never a flattened raster. Keep "Selection only" **off** so all fonts embed.
- **Never outline, rasterize, or convert type to paths.** Headlines included.
- Because the faces are Georgia and Arial (§1a), a placed PDF relinks in InDesign by **exact
  family name** with no reflow. If a font shows as a subset (`ABCDE+Georgia`), relink via
  **Type ▸ Find/Replace Font** — the base name matches, so it reflows cleanly.
- This is the main practical reason the webfonts are gone: a hosted or self-hosted font's
  subset/build name won't match an installed desktop face, and the relink silently fails.
  Using a non-brand font is an InDesign-import failure, not just a styling error.
- Don't set type inside an image, a `<canvas>`, or an SVG `<text>` element — it arrives as
  art, not text.

### 7b. Build layouts that survive the import — flow, don't grid

A browser-exported PDF has no concept of CSS grid or flexbox. Each cell becomes a separately
positioned text frame, so a grid of cells (number + title + body per cell) imports into
InDesign as dozens of disconnected boxes that cannot be reconciled into an editable list.

- **Build lists and multi-item content as normal block-level paragraphs in document order.**
- For multiple columns use **real CSS columns** (`column-count` / `column-gap`) on the
  container — never `display:grid` or a row of flex `<div>`s for text meant to read as a
  continuous list.
- **One paragraph per item.** Collapse each list item into a single `<p>` with inline emphasis
  (`<span>` / `<strong>`) for the number and bold lead-in, rather than stacking separate
  number/title/body divs. Fewer nested containers means fewer fragmented frames.
- Reserve grid and flex for purely visual, non-reflowing arrangements — a header row with a
  logo and an eyebrow, for instance — not for text runs.
- Keep the DOM shallow. Every extra wrapper is a potential extra frame.
- Tables: use a real `<table>`. It imports far more predictably than a grid mimicking one.

### 7c. Page geometry

- **0.5in margins on all four sides** (§4), identical on every page, so the InDesign master
  page matches the PDF without adjustment.
- Set an explicit page size (Letter unless told otherwise) and consistent column gutters
  (0.375in). Don't rely on browser defaults.
- Full-bleed backgrounds may run to the page edge; text inside them still respects the 0.5in
  inset.

### 7d. Set expectations honestly

Even done correctly, a browser PDF imports as **positioned text, not a threaded InDesign
story.** Columns may land as separate blocks. Each item stays intact and editable, and fonts
and colors relink cleanly — but a heavy, list-dense layout is most reliably rebuilt natively
in InDesign using this copy and these styles. Say so rather than implying a one-click
round-trip.

---

## 8. Restyling a source (document, page, or file provided to you)

When a source is provided to be restyled or re-laid-out, treat its **content as fixed and its
visual design as the only thing you may change.** The task is to change how the material
*looks*, never what it *says*.

- **Copy every piece of content verbatim** — exact wording, spelling, capitalization,
  punctuation, numbers, dates, units, symbols, and order. Do not paraphrase, summarize,
  expand, condense, rewrite, "improve," translate, or reorder. Reproduce headings, list
  nesting, section sequence, and table rows/columns as-is.
- **Only visual styling may change:** fonts, colors, sizes, spacing, alignment, backgrounds,
  imagery, arrangement. Emphasis (bold, weight, size, color) is allowed **only when it
  doesn't alter meaning.**
- **Never silently** drop or truncate content to make it fit (reflow, resize, or split
  instead); add content that isn't in the source (no invented headlines, taglines, stats,
  sample data, or filler); fix apparent typos, grammar, or factual errors (flag them, leave
  the original); round or reformat numbers and dates; or merge, split, or re-sequence
  sections.
- **Text baked into an image stays in the image** — preserve as-is and note it. Don't retype
  or re-typeset it as live text.
- **Template prompt text is not content.** Empty-placeholder prompts ("Click to edit…") are
  layout artifacts — don't copy them into the output.
- **Three styling overrides apply even to verbatim material:** corner radius → square,
  off-brand color → nearest brand equivalent, and spaced em dash → tight.
- **When something won't fit,** never resolve it by cutting or summarizing. Enlarge the
  container, reduce the font within reason, reflow, or split across additional pages — and if
  none of that works, stop and ask.

---

## 9. Pre-delivery checklist

Run this before calling any design deliverable finished.

1. **Fonts** — every element resolves to Georgia or Arial. No webfont loaded. No Calibri,
   Times, Helvetica, Inter, or Source Serif anywhere. Titles are Regular weight, not bold.
2. **Corners** — every box, card, image frame, button, and input is square. Radius 0.
3. **White boxes** — no stroke on any white box sitting on cream, black, or Access.
4. **Color** — every value traces to the palette in §2. No off-brand color or invented tint.
   Accents are sparing and never full-bleed. Access is not used on body copy.
5. **Case** — headlines and subheads in sentence case; eyebrows ALL CAPS; nothing
   title-cased.
6. **Em dashes** — all tight, no spaces, including in copied material.
7. **Copy** — compliance substitutions applied, no guarantees or superlatives, no invented
   stats or dates, "and" not "&", correct advisor term for the audience.
8. **Disclosures** — present and complete, or explicitly flagged as missing.
9. **Fidelity** (restyle jobs) — extract the output text and compare against the source:
   nothing added, dropped, reworded, or reordered; every number, date, name, and label
   matches; section order and hierarchy match. Report anything that couldn't be preserved
   (e.g. text inside images) and why.
10. **Margins and scale** — 0.5in margins on all four sides of every page, spacing values on the 4px scale, body copy
    at 10pt print / 16px screen, nothing below the minimum sizes.
11. **InDesign compatibility** (any PDF) — type is live and not outlined; no text baked into
    images, canvas, or SVG; lists are flowing paragraphs (one `<p>` per item), columns are
    real CSS columns, no grid or flex holding text; page size and margins explicit. Note in
    the hand-off that it imports as positioned text, not a threaded story.

---

## 10. When to stop and ask

Stop and ask rather than guessing when:
- Content won't fit and the only remaining options are cutting or summarizing.
- The output size, medium, or page count isn't specified.
- An asset is needed (logo variant, photograph, chart data) and you'd otherwise invent it.
- A statistic, ranking, AUM figure, date, or designation is required and unverified.
- The source's design conflicts with these rules in a way an override can't resolve.
- A required disclosure appears to be missing.

*This file is a distillation of the Mariner design system and brand guidance. Where a fuller
internal source exists — the color palette PDF, the brand voice document, the design system
itself — that source takes precedence.*
