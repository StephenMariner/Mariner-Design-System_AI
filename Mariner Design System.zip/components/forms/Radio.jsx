import React from "react";

/** Radio option with label. Use several with the same `name`. */
export function Radio({ label, name, value, checked, defaultChecked, style = {}, ...rest }) {
  return (
    <label style={{
      display: "inline-flex", alignItems: "center", gap: "0.625rem",
      fontFamily: "var(--font-body)", fontSize: "var(--text-body-sm)",
      color: "var(--text-body)", cursor: "pointer", ...style,
    }}>
      <input type="radio" name={name} value={value} checked={checked} defaultChecked={defaultChecked}
        style={{ width: "1.05rem", height: "1.05rem", accentColor: "var(--black)", cursor: "pointer" }}
        {...rest} />
      {label}
    </label>
  );
}
