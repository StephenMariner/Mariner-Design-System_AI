**Radio** — single choice within a group; share one `name` across options.

```jsx
<Radio name="contact" value="email" label="Email" defaultChecked />
<Radio name="contact" value="phone" label="Phone" />
```
