import React from "react";
export interface TextareaProps {
  label?: string;
  required?: boolean;
  id?: string;
  rows?: number;
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Multi-line text field matching Input styling. */
export function Textarea(props: TextareaProps): JSX.Element;
