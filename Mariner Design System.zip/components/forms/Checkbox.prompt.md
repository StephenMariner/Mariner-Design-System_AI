**Checkbox** — opt-in toggle for consent lines and multi-select lists.

```jsx
<Checkbox label="Subscribe to the newsletter" defaultChecked />
```
