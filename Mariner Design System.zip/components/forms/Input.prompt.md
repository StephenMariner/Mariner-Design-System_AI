**Input** — single-line text field with optional uppercase label and required marker; the building block of Mariner's contact forms.

```jsx
<Input label="First Name" required placeholder="Jane" />
<Input label="Email" type="email" error="Enter a valid email" />
```
