import React from "react";
export interface SelectProps {
  label?: string;
  required?: boolean;
  id?: string;
  placeholder?: string;
  options?: Array<string | { value: string; label: string }>;
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Dropdown select with custom chevron, matching form field styling. */
export function Select(props: SelectProps): JSX.Element;
