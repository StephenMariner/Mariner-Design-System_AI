import React from "react";
export interface RadioProps {
  label?: React.ReactNode;
  name: string;
  value?: string;
  checked?: boolean;
  defaultChecked?: boolean;
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Single radio option; group several sharing one `name`. */
export function Radio(props: RadioProps): JSX.Element;
