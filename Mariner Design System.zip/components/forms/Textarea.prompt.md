**Textarea** — multi-line message field for contact forms.

```jsx
<Textarea label="Message" required rows={5} />
```
