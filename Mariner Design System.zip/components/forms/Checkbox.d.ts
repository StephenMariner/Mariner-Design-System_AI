import React from "react";
export interface CheckboxProps {
  label?: React.ReactNode;
  checked?: boolean;
  defaultChecked?: boolean;
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Checkbox with inline label; navy accent when checked. */
export function Checkbox(props: CheckboxProps): JSX.Element;
