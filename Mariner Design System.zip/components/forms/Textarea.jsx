import React from "react";

/** Multi-line text input matching Input's styling. */
export function Textarea({ label, required = false, id, rows = 4, style = {}, ...rest }) {
  const inputId = id || (label ? `ta-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.375rem", width: "100%" }}>
      {label && (
        <label htmlFor={inputId} style={{
          fontFamily: "var(--font-ui)", fontSize: "var(--text-caption)",
          fontWeight: "var(--weight-semibold)", letterSpacing: "var(--tracking-wide)",
          textTransform: "uppercase", color: "var(--text-muted)",
        }}>
          {label}{required && <span style={{ color: "var(--danger)" }}> *</span>}
        </label>
      )}
      <textarea
        id={inputId} rows={rows}
        style={{
          fontFamily: "var(--font-body)", fontSize: "var(--text-body)",
          color: "var(--text-body)", background: "var(--surface-raised)",
          border: "1px solid var(--border-default)", borderRadius: "var(--radius-md)",
          padding: "0.6875rem 0.875rem", width: "100%", outline: "none", resize: "vertical",
          transition: "border-color 0.18s ease, box-shadow 0.18s ease", ...style,
        }}
        onFocus={(e) => { e.currentTarget.style.borderColor = "var(--rust)"; e.currentTarget.style.boxShadow = "var(--shadow-focus)"; }}
        onBlur={(e) => { e.currentTarget.style.borderColor = "var(--border-default)"; e.currentTarget.style.boxShadow = "none"; }}
        {...rest}
      />
    </div>
  );
}
