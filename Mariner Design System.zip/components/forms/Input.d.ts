import React from "react";
export interface InputProps {
  label?: string;
  required?: boolean;
  id?: string;
  error?: string;
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Text input with optional uppercase label, required marker, and error state. */
export function Input(props: InputProps): JSX.Element;
