**Select** — dropdown for constrained choices (e.g. the "Are You A:" field).

```jsx
<Select label="Are You A:" required placeholder="Select one"
  options={["Client","Prospective Client","Advisor","Other"]} />
```
