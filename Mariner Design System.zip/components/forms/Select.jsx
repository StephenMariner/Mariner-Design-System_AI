import React from "react";

/** Select dropdown matching form styling ("Are You A:" pattern). */
export function Select({ label, required = false, id, options = [], placeholder, style = {}, ...rest }) {
  const inputId = id || (label ? `sel-${label.replace(/\s+/g, "-").toLowerCase()}` : undefined);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "0.375rem", width: "100%" }}>
      {label && (
        <label htmlFor={inputId} style={{
          fontFamily: "var(--font-ui)", fontSize: "var(--text-caption)",
          fontWeight: "var(--weight-semibold)", letterSpacing: "var(--tracking-wide)",
          textTransform: "uppercase", color: "var(--text-muted)",
        }}>
          {label}{required && <span style={{ color: "var(--danger)" }}> *</span>}
        </label>
      )}
      <select
        id={inputId}
        style={{
          fontFamily: "var(--font-body)", fontSize: "var(--text-body)",
          color: "var(--text-body)", background: "var(--surface-raised)",
          border: "1px solid var(--border-default)", borderRadius: "var(--radius-md)",
          padding: "0.6875rem 0.875rem", width: "100%", outline: "none", cursor: "pointer",
          appearance: "none",
          backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath fill='%236B7780' d='M1 1l5 5 5-5'/%3E%3C/svg%3E\")",
          backgroundRepeat: "no-repeat", backgroundPosition: "right 0.875rem center",
          transition: "border-color 0.18s ease, box-shadow 0.18s ease", ...style,
        }}
        onFocus={(e) => { e.currentTarget.style.borderColor = "var(--rust)"; e.currentTarget.style.boxShadow = "var(--shadow-focus)"; }}
        onBlur={(e) => { e.currentTarget.style.borderColor = "var(--border-default)"; e.currentTarget.style.boxShadow = "none"; }}
        {...rest}
      >
        {placeholder && <option value="">{placeholder}</option>}
        {options.map((o) => {
          const val = typeof o === "string" ? o : o.value;
          const lbl = typeof o === "string" ? o : o.label;
          return <option key={val} value={val}>{lbl}</option>;
        })}
      </select>
    </div>
  );
}
