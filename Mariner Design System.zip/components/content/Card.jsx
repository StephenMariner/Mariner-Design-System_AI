import React from "react";

/**
 * Card — content container. Two surfaces: light (default, on cream) and
 * a subtle raised variant with border. Used for insights teasers, service
 * blocks, form panels.
 */
export function Card({ children, variant = "default", padding = "1.75rem", style = {}, ...rest }) {
  const variants = {
    default: {
      background: "var(--surface-raised)",
      border: "1px solid var(--border-subtle)",
      boxShadow: "var(--shadow-sm)",
    },
    flat: {
      background: "var(--surface-sunken)",
      border: "1px solid transparent",
      boxShadow: "none",
    },
    outline: {
      background: "transparent",
      border: "1px solid var(--border-default)",
      boxShadow: "none",
    },
    inverse: {
      background: "var(--surface-inverse)",
      border: "1px solid var(--border-on-dark)",
      boxShadow: "none",
    },
  };
  return (
    <div
      style={{
        borderRadius: "var(--radius-md)",
        padding,
        color: variant === "inverse" ? "var(--text-on-dark)" : "var(--text-body)",
        ...variants[variant],
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
