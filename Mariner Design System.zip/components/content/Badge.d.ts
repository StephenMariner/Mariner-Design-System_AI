import React from "react";
export interface BadgeProps {
  children: React.ReactNode;
  /** @default "neutral" */
  tone?: "neutral" | "accent" | "navy" | "success" | "warning" | "danger";
  /** Inverts the outline and text to white for placement on black/dark surfaces. @default false */
  onDark?: boolean;
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Stroke-outline label pill — transparent fill, stroke and text always the same color. */
export function Badge(props: BadgeProps): JSX.Element;
