**Blockquote** — italic serif pull quote with a brass left rule; use for testimonials and editorial emphasis.

```jsx
<Blockquote cite="Marty Bicknell, CEO">
  Real power behind your plan.
</Blockquote>
```

Use `tone="onDark"` on navy sections.
