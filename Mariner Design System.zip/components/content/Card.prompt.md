**Card** — surface container for teasers, service blocks, and form panels.

```jsx
<Card>
  <Eyebrow>Insights</Eyebrow>
  <h3>A new Fed, familiar market dynamics</h3>
  <TextLink href="#">Read</TextLink>
</Card>
```

Variants: `default` (white, soft shadow), `flat` (cream, no shadow), `outline`, `inverse` (navy). Override `padding` as needed.
