**Badge** — stroke-outline label. Transparent fill; stroke and text always match.

```jsx
<Badge>Podcast</Badge>              {/* black stroke + black text on light */}
<Badge onDark>Podcast</Badge>       {/* white stroke + white text on black */}
<Badge tone="success">Active</Badge>
```

- On white/cream surfaces: black stroke, black text. On black/dark surfaces: pass `onDark` for the inverse.
- Never filled — no background tint. Square corners, per the brand radius rule.
- `tone="success" | "warning" | "danger"` keeps its semantic color for both stroke and text.
