import React from "react";

/**
 * Stat — large serif figure with label, for accolades and metrics
 * (e.g. "#6 Mega RIA", "$100B+ AUM").
 */
export function Stat({ value, label, tone = "default", align = "left", style = {}, ...rest }) {
  const onDark = tone === "onDark";
  return (
    <div style={{ textAlign: align, ...style }} {...rest}>
      <div style={{
        fontFamily: "var(--font-serif)",
        fontSize: "var(--text-display-m)",
        fontWeight: "var(--weight-title)",
        lineHeight: 1,
        letterSpacing: "var(--tracking-tight)",
        color: onDark ? "var(--fast)" : "var(--text-heading-accent)",
      }}>
        {value}
      </div>
      {label && (
        <div style={{
          marginTop: "0.5rem",
          fontFamily: "var(--font-ui)",
          fontSize: "var(--text-body-sm)",
          color: onDark ? "var(--text-on-dark-muted)" : "var(--text-muted)",
          maxWidth: "22ch",
          ...(align === "center" ? { marginInline: "auto" } : {}),
        }}>
          {label}
        </div>
      )}
    </div>
  );
}
