import React from "react";

/**
 * Accordion — expandable list, as used in the "Your needs evolve" section
 * (Executives / Athletes / Business Owners …). Serif headers, brass +/- marker.
 */
export function Accordion({ items = [], defaultOpen = 0, style = {}, ...rest }) {
  const [open, setOpen] = React.useState(defaultOpen);
  return (
    <div style={{ borderTop: "1px solid var(--border-subtle)", ...style }} {...rest}>
      {items.map((item, i) => {
        const isOpen = open === i;
        return (
          <div key={i} style={{ borderBottom: "1px solid var(--border-subtle)" }}>
            <button
              onClick={() => setOpen(isOpen ? -1 : i)}
              style={{
                display: "flex", alignItems: "center", justifyContent: "space-between",
                width: "100%", gap: "1rem", padding: "1.25rem 0",
                background: "transparent", border: "none", cursor: "pointer", textAlign: "left",
              }}
            >
              <span style={{
                fontFamily: "var(--font-serif)", fontSize: "var(--text-h4)",
                fontWeight: "var(--weight-title)", color: "var(--text-strong)",
              }}>
                {item.title}
              </span>
              <span aria-hidden="true" style={{
                fontFamily: "var(--font-ui)", fontSize: "1.25rem", lineHeight: 1,
                color: "var(--rust)", flexShrink: 0,
                transition: "transform 0.2s ease", transform: isOpen ? "rotate(45deg)" : "none",
              }}>
                +
              </span>
            </button>
            {isOpen && (
              <div style={{
                paddingBottom: "1.5rem", maxWidth: "62ch",
                fontFamily: "var(--font-body)", fontSize: "var(--text-body)",
                lineHeight: "var(--leading-relaxed)", color: "var(--text-body)",
              }}>
                {item.content}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
