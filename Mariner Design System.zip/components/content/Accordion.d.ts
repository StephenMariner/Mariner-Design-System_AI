import React from "react";
export interface AccordionItem {
  title: React.ReactNode;
  content: React.ReactNode;
}
export interface AccordionProps {
  items: AccordionItem[];
  /** Index open by default; -1 for all closed. @default 0 */
  defaultOpen?: number;
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Expandable list with serif headers and brass +/× marker. */
export function Accordion(props: AccordionProps): JSX.Element;
