import React from "react";

/** Divider — hairline rule. Optional short brass "accent" style. */
export function Divider({ variant = "default", tone = "default", style = {}, ...rest }) {
  const onDark = tone === "onDark";
  if (variant === "accent") {
    return <hr style={{ border: 0, height: "2px", width: "48px", background: "var(--rule-accent)", margin: 0, ...style }} {...rest} />;
  }
  return (
    <hr style={{
      border: 0, height: "1px",
      background: onDark ? "var(--border-on-dark)" : "var(--border-subtle)",
      margin: 0, ...style,
    }} {...rest} />
  );
}
