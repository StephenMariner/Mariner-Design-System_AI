**Divider** — separator rule.

```jsx
<Divider />
<Divider variant="accent" />  {/* short brass bar under a heading */}
```
