import React from "react";
export interface BlockquoteProps {
  children: React.ReactNode;
  /** Attribution line. */
  cite?: React.ReactNode;
  /** @default "default" */
  tone?: "default" | "onDark";
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Italic serif pull quote with brass left rule. */
export function Blockquote(props: BlockquoteProps): JSX.Element;
