import React from "react";
/**
 * Content container / panel.
 * @startingPoint section="Content" subtitle="Card surfaces and variants" viewport="700x300"
 */
export interface CardProps {
  children: React.ReactNode;
  /** @default "default" */
  variant?: "default" | "flat" | "outline" | "inverse";
  /** CSS padding. @default "1.75rem" */
  padding?: string;
  style?: React.CSSProperties;
  [key: string]: any;
}
export function Card(props: CardProps): JSX.Element;
