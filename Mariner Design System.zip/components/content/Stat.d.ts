import React from "react";
export interface StatProps {
  /** Large figure, e.g. "#6" or "$100B+". */
  value: React.ReactNode;
  /** Supporting caption below the figure. */
  label?: React.ReactNode;
  /** @default "default" */
  tone?: "default" | "onDark";
  /** @default "left" */
  align?: "left" | "center";
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Large serif figure + caption for accolades and metrics. */
export function Stat(props: StatProps): JSX.Element;
