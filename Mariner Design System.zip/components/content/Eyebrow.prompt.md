**Eyebrow** — small uppercase overline placed directly above a serif heading, a signature of Mariner's section intros ("WHAT WE OFFER", "INSIGHTS").

```jsx
<Eyebrow>What We Offer</Eyebrow>
<h2>Services for individuals</h2>
```

Tones: `accent` (brass, default), `muted`, `onDark` (for navy sections).
