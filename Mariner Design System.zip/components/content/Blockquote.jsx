import React from "react";

/** Blockquote — editorial pull quote with serif type and brass rule. */
export function Blockquote({ children, cite, tone = "default", style = {}, ...rest }) {
  const onDark = tone === "onDark";
  return (
    <figure style={{ margin: 0, paddingLeft: "1.5rem", borderLeft: "3px solid var(--rule-accent)", ...style }} {...rest}>
      <blockquote style={{
        margin: 0,
        fontFamily: "var(--font-serif)",
        fontSize: "var(--text-h3)",
        fontWeight: "var(--weight-regular)",
        fontStyle: "italic",
        lineHeight: "var(--leading-snug)",
        color: onDark ? "var(--text-on-dark)" : "var(--text-strong)",
      }}>
        {children}
      </blockquote>
      {cite && (
        <figcaption style={{
          marginTop: "1rem",
          fontFamily: "var(--font-ui)",
          fontSize: "var(--text-caption)",
          fontWeight: "var(--weight-semibold)",
          letterSpacing: "var(--tracking-eyebrow)",
          textTransform: "uppercase",
          color: onDark ? "var(--text-on-dark-muted)" : "var(--text-muted)",
        }}>
          {cite}
        </figcaption>
      )}
    </figure>
  );
}
