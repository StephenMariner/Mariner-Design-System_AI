**Stat** — oversized serif figure with a caption, for accolades and headline metrics.

```jsx
<Stat value="#6" label="Mega RIA — Barron's, 2025" />
<Stat value="$100B+" label="Assets under advisement" tone="onDark" align="center" />
```
