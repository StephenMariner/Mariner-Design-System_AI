import React from "react";
export interface EyebrowProps {
  children: React.ReactNode;
  /** @default "accent" */
  tone?: "accent" | "access" | "muted" | "onDark";
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Uppercase overline label that sits above section headings. */
export function Eyebrow(props: EyebrowProps): JSX.Element;
