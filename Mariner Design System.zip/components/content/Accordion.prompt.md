**Accordion** — single-open expandable list for segmented content (client types, FAQs).

```jsx
<Accordion defaultOpen={0} items={[
  { title: "Executives", content: "Financial planning for compensation packages…" },
  { title: "Business Owners", content: "Valuation, cash flow, succession…" },
]} />
```
