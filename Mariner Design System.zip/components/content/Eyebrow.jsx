import React from "react";

/** Eyebrow — uppercase overline label above headings. Arial Regular; Access or Rust per brand. */
export function Eyebrow({ children, tone = "accent", style = {}, ...rest }) {
  const tones = {
    accent: "var(--text-accent)",
    access: "var(--text-heading-accent)",
    muted: "var(--text-muted)",
    onDark: "var(--fast)",
  };
  return (
    <span
      style={{
        display: "inline-block",
        fontFamily: "var(--font-ui)",
        fontSize: "var(--text-eyebrow)",
        fontWeight: "var(--weight-eyebrow)",
        letterSpacing: "var(--tracking-eyebrow)",
        textTransform: "uppercase",
        color: tones[tone],
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
