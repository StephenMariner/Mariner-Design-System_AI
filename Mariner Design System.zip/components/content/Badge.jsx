import React from "react";

/** Badge — stroke-outline label. Stroke and text always match. */
export function Badge({ children, tone = "neutral", onDark = false, style = {}, ...rest }) {
  const tones = {
    neutral: onDark ? "var(--white)" : "var(--black)",
    accent: onDark ? "var(--white)" : "var(--black)",
    navy: onDark ? "var(--white)" : "var(--black)",
    success: "var(--success)",
    warning: "var(--warning)",
    danger: "var(--danger)",
  };
  const ink = tones[tone] || tones.neutral;
  return (
    <span
      style={{
        display: "inline-flex", alignItems: "center",
        fontFamily: "var(--font-ui)", fontSize: "var(--text-caption)",
        fontWeight: "var(--weight-semibold)", lineHeight: 1,
        padding: "0.3rem 0.6rem", borderRadius: "var(--radius-pill)",
        background: "transparent", color: ink, border: `1px solid ${ink}`,
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
