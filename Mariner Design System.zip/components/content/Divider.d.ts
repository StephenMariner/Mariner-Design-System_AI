import React from "react";
export interface DividerProps {
  /** @default "default" */
  variant?: "default" | "accent";
  /** @default "default" */
  tone?: "default" | "onDark";
  style?: React.CSSProperties;
  [key: string]: any;
}
/** Hairline rule; `accent` renders a short brass bar. */
export function Divider(props: DividerProps): JSX.Element;
