import React from "react";

export interface TextLinkProps {
  children: React.ReactNode;
  href?: string;
  /** Show trailing chevron. @default true */
  arrow?: boolean;
  /** @default "default" */
  tone?: "default" | "accent" | "onDark";
  style?: React.CSSProperties;
  [key: string]: any;
}

/** Inline editorial CTA link with trailing chevron ("Read >", "Learn More"). */
export function TextLink(props: TextLinkProps): JSX.Element;
