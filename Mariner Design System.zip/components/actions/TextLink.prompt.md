**TextLink** — inline, underlined CTA link with a trailing chevron; use inside cards, article teasers, and section footers.

```jsx
<TextLink href="/insights">See All Insights</TextLink>
<TextLink tone="onDark" href="#">Learn More</TextLink>
```

Tones: `default` (navy), `accent` (brass), `onDark` (cream, for navy sections). Set `arrow={false}` to drop the chevron.
