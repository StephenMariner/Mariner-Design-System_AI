import React from "react";

/**
 * Mariner Button — primary call-to-action.
 * Brand CTAs are uppercase, letter-spaced, squared corners.
 * Resting fills are white, black, or cream only — rust is never a resting state.
 * All variants hover to Access blue with white text.
 */
export function Button({
  children,
  variant = "primary",   // primary | accent | secondary | ghost
  size = "md",           // sm | md | lg
  as = "button",
  disabled = false,
  fullWidth = false,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: { padding: "0.5rem 1rem", fontSize: "0.6875rem" },
    md: { padding: "0.8125rem 1.5rem", fontSize: "0.75rem" },
    lg: { padding: "1rem 2rem", fontSize: "0.8125rem" },
  };

  const variants = {
    primary: {
      background: "var(--action-primary)",
      color: "var(--action-primary-text)",
      border: "1px solid var(--action-primary)",
    },
    accent: {
      background: "var(--action-accent)",
      color: "var(--action-accent-text)",
      border: "1px solid var(--action-accent-border)",
    },
    secondary: {
      background: "transparent",
      color: "var(--action-primary)",
      border: "1px solid var(--border-strong)",
    },
    ghost: {
      background: "transparent",
      color: "var(--action-primary)",
      border: "1px solid transparent",
    },
  };

  const Tag = as;
  return (
    <Tag
      disabled={as === "button" ? disabled : undefined}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: "0.5rem",
        width: fullWidth ? "100%" : "auto",
        fontFamily: "var(--font-ui)",
        fontWeight: "var(--weight-semibold)",
        letterSpacing: "var(--tracking-eyebrow)",
        textTransform: "uppercase",
        lineHeight: 1,
        borderRadius: "var(--radius-sm)",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.45 : 1,
        transition: "background 0.18s ease, color 0.18s ease, border-color 0.18s ease",
        textDecoration: "none",
        ...sizes[size],
        ...variants[variant],
        ...style,
      }}
      onMouseEnter={(e) => {
        if (disabled) return;
        e.currentTarget.style.background = "var(--action-hover-bg)";
        e.currentTarget.style.color = "var(--action-hover-text)";
        e.currentTarget.style.borderColor = "var(--action-hover-bg)";
      }}
      onMouseLeave={(e) => {
        if (disabled) return;
        e.currentTarget.style.background = variants[variant].background;
        e.currentTarget.style.color = variants[variant].color;
        e.currentTarget.style.borderColor = variant === "secondary"
          ? "var(--border-strong)"
          : variant === "ghost" ? "transparent"
          : variant === "accent" ? "var(--action-accent-border)"
          : variants[variant].background;
      }}
      {...rest}
    >
      {children}
    </Tag>
  );
}
