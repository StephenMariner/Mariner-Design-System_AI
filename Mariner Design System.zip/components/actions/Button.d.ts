import React from "react";

/**
 * Primary call-to-action button. Uppercase, letter-spaced, squared corners.
 * @startingPoint section="Actions" subtitle="CTA buttons in all variants" viewport="700x220"
 */
export interface ButtonProps {
  children: React.ReactNode;
  /** Visual style. @default "primary" */
  variant?: "primary" | "accent" | "secondary" | "ghost";
  /** @default "md" */
  size?: "sm" | "md" | "lg";
  /** Render as a different element, e.g. "a". @default "button" */
  as?: "button" | "a";
  disabled?: boolean;
  fullWidth?: boolean;
  style?: React.CSSProperties;
  [key: string]: any;
}

export function Button(props: ButtonProps): JSX.Element;
