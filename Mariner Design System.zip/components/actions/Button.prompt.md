**Button** — primary call-to-action; use for form submits, hero CTAs, and section actions. Labels are uppercase and letter-spaced by design.

```jsx
<Button variant="primary" size="lg">Talk to an Advisor</Button>
<Button variant="accent">Register Now</Button>  {/* cream fill, black stroke + text */}
<Button variant="secondary" as="a" href="#">See All Insights</Button>
```

Variants: `primary` (navy, default), `accent` (brass), `secondary` (outline, fills navy on hover), `ghost`. Sizes: `sm` / `md` / `lg`. Pass `as="a"` for link buttons, `fullWidth` inside forms.
