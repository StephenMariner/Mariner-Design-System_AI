import React from "react";

/**
 * TextLink — inline editorial CTA with a trailing chevron, as seen in
 * "Read >" / "Learn More" links across the site.
 */
export function TextLink({ children, href = "#", arrow = true, tone = "default", style = {}, ...rest }) {
  const tones = {
    default: "var(--text-link)",
    accent: "var(--text-accent)",
    onDark: "var(--cream)",
  };
  return (
    <a
      href={href}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "0.4rem",
        fontFamily: "var(--font-ui)",
        fontWeight: "var(--weight-semibold)",
        fontSize: "var(--text-body-sm)",
        letterSpacing: "var(--tracking-wide)",
        textTransform: "uppercase",
        color: tones[tone],
        textDecoration: "none",
        borderBottom: "1px solid currentColor",
        paddingBottom: "2px",
        transition: "opacity 0.18s ease",
        ...style,
      }}
      onMouseEnter={(e) => (e.currentTarget.style.opacity = "0.65")}
      onMouseLeave={(e) => (e.currentTarget.style.opacity = "1")}
      {...rest}
    >
      {children}
      {arrow && <span aria-hidden="true" style={{ fontWeight: 400 }}>&rsaquo;</span>}
    </a>
  );
}
