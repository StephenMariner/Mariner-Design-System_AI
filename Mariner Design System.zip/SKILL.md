---
name: mariner-design
description: Use this skill to generate well-branded interfaces and assets for Mariner (Mariner Wealth Advisors), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference
- **Fonts:** Georgia (titles — **Regular weight only**, action words may be *italicized*) + Arial Regular (headers, body, UI). Both are system faces — no webfonts. Body copy is 10pt in print.
- **Official colors:** primaries Black `#000000`, Cream `#F0E6DD`, White, Access blue `#2294BD` (all may be full-bleed; use Access cautiously). Accents Rust `#D9532B` + Fast `#FAA51A` — sparing, **never full-bleed**, captions/labels/CTAs/wayfinding only. Access on headlines/large text only, never body copy.
- **Logo:** official wordmark PNGs in `assets/` (Black on light, Cream on black, White for high contrast). Never redraw it.
- **Voice:** second-person, confident, plain-spoken; sentence-case titles; hedged compliance language; numbered footnotes for stats; no emoji.
- **Layout registers:** elevated pieces = asymmetric grids, full-bleed black/cream/access moments, oversized serif titles; standard/article/form pieces = reserved, symmetrical, two-column 10pt body with consistent 0.75in margins and disclosure footer.
- **Tokens:** link `styles.css`. **Components:** load `_ds_bundle.js`, read from `window.MarinerDesignSystem_43493c`.
